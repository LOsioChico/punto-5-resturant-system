--
-- PostgreSQL database dump
--

\restrict 4zyMRggx3lIlQRbHLhMenbzaj69TVJU6yxa91a1kex0m0KjgVjKXMadOkPVtkRu

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', 'c665a50e-577d-4ed3-a635-715c32df68a4', 'authenticated', 'authenticated', '1235340086@punto5.co', '$2a$10$t378T/mWaMVT65fvUc1.JOasISfYhK5HAVSVpHMNJxNxndOLkH5hO', '2026-07-10 23:40:37.185721+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-10-02 21:50:47.885684+00', '{"role": "waiter", "provider": "email", "providers": ["email"]}', '{"name": "Luis Mesero", "role": "waiter", "cedula": "1235340086", "email_verified": true}', NULL, '2026-07-10 23:40:37.154033+00', '2026-10-02 21:50:47.97293+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);
INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', 'authenticated', 'authenticated', 'osiochico@gmail.com', '$2a$10$bHkI3JKgbBZ4GnJTvnZrmejy6SOIC6bXEvAYd2ku/tInKEfmAkTm6', '2026-06-28 21:59:26.517157+00', NULL, '', NULL, '', '2026-07-06 22:12:28.818815+00', '', '', NULL, '2026-07-06 22:17:17.934172+00', '{"role": "admin", "provider": "email", "providers": ["email"]}', '{"full_name": "Luis", "email_verified": true}', NULL, '2026-06-28 21:59:26.500231+00', '2026-07-15 21:22:38.492761+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('f5d56202-ff1c-44f3-b720-5d5d8e727579', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '{"sub": "f5d56202-ff1c-44f3-b720-5d5d8e727579", "email": "osiochico@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-06-28 21:59:26.51219+00', '2026-06-28 21:59:26.512241+00', '2026-06-28 21:59:26.512241+00', 'bdb02c21-c01a-46ef-80c6-9b3d8a5f9227');
INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('c665a50e-577d-4ed3-a635-715c32df68a4', 'c665a50e-577d-4ed3-a635-715c32df68a4', '{"sub": "c665a50e-577d-4ed3-a635-715c32df68a4", "email": "1235340086@punto5.co", "email_verified": false, "phone_verified": false}', 'email', '2026-07-10 23:40:37.180846+00', '2026-07-10 23:40:37.180907+00', '2026-07-10 23:40:37.180907+00', 'e57473d6-efcb-417c-95d6-878957852281');


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('de3db262-3344-40f6-abab-3515504ad152', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-07-06 22:17:17.935381+00', '2026-07-15 21:22:38.501869+00', NULL, 'aal1', NULL, '2026-07-15 21:22:38.50175', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '186.169.90.41', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('3e0f0137-4b17-4803-ba3a-346b8bcebeb0', 'c665a50e-577d-4ed3-a635-715c32df68a4', '2026-09-02 03:17:17.9086+00', '2026-09-17 04:24:23.751218+00', NULL, 'aal1', NULL, '2026-09-17 04:24:23.751107', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Safari/605.1.15', '186.80.54.0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('4c6094e7-7812-4f80-93bd-32ab09383cdb', 'c665a50e-577d-4ed3-a635-715c32df68a4', '2026-10-02 21:50:47.885788+00', '2026-10-02 21:50:47.885788+00', NULL, 'aal1', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '186.169.83.90', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('23cbcd39-7190-45b1-8348-dbae1a27f949', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-07-06 22:12:19.622545+00', '2026-07-06 22:12:19.622545+00', NULL, 'aal1', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('ce65dbda-f33a-4ef8-9858-a2f819675aab', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-07-06 22:12:34.79468+00', '2026-07-06 22:12:34.79468+00', NULL, 'aal1', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('23cbcd39-7190-45b1-8348-dbae1a27f949', '2026-07-06 22:12:19.647815+00', '2026-07-06 22:12:19.647815+00', 'otp', '77ab4f11-36a4-427f-9a53-59d91261d5bb');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('ce65dbda-f33a-4ef8-9858-a2f819675aab', '2026-07-06 22:12:34.797379+00', '2026-07-06 22:12:34.797379+00', 'otp', 'cdd68f13-8320-4228-825f-18cfe00b3d52');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('de3db262-3344-40f6-abab-3515504ad152', '2026-07-06 22:17:17.951577+00', '2026-07-06 22:17:17.951577+00', 'password', '30ac9eaf-fc9e-40d9-afec-d4d7e843a89d');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('3e0f0137-4b17-4803-ba3a-346b8bcebeb0', '2026-09-02 03:17:17.929244+00', '2026-09-02 03:17:17.929244+00', 'password', '6b41622e-84d3-44d5-b3d3-13e000aab8e9');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('4c6094e7-7812-4f80-93bd-32ab09383cdb', '2026-10-02 21:50:47.9963+00', '2026-10-02 21:50:47.9963+00', 'password', 'e9ec433a-20bd-496a-b67d-25a31482cab9');


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: mfa_recovery_code_sets; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 60, 'sh4dxbytxjxz', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-07-06 22:12:19.637658+00', '2026-07-06 22:12:19.637658+00', NULL, '23cbcd39-7190-45b1-8348-dbae1a27f949');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 61, 'swntufvyyv4c', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-07-06 22:12:34.795807+00', '2026-07-06 22:12:34.795807+00', NULL, 'ce65dbda-f33a-4ef8-9858-a2f819675aab');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 62, 'jnqu3ub4v2pe', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-06 22:17:17.946345+00', '2026-07-08 04:38:58.157899+00', NULL, 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 63, 'juxdjcbdif2f', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-08 04:38:58.171288+00', '2026-07-10 23:40:22.066256+00', 'jnqu3ub4v2pe', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 64, 'e7mjfopwj57h', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-10 23:40:22.078523+00', '2026-07-11 00:38:49.966838+00', 'juxdjcbdif2f', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 66, 'jsbh3e5irfj4', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-11 00:38:49.989037+00', '2026-07-11 03:48:00.815851+00', 'e7mjfopwj57h', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 67, '4mkusj55dhgj', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-11 03:48:00.826112+00', '2026-07-15 04:31:28.819893+00', 'jsbh3e5irfj4', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 71, '7nhke6lbc6jo', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-15 04:31:28.829763+00', '2026-07-15 14:30:09.123007+00', '4mkusj55dhgj', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 72, 't3h3oz4tdufk', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-07-15 14:30:09.131385+00', '2026-07-15 21:22:38.474525+00', '7nhke6lbc6jo', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 73, 'p2pnxtedlcj7', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-07-15 21:22:38.486566+00', '2026-07-15 21:22:38.486566+00', 't3h3oz4tdufk', 'de3db262-3344-40f6-abab-3515504ad152');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 77, 'aq6se2pxdpoe', 'c665a50e-577d-4ed3-a635-715c32df68a4', true, '2026-09-02 03:17:17.920253+00', '2026-09-03 00:00:05.230305+00', NULL, '3e0f0137-4b17-4803-ba3a-346b8bcebeb0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 78, '2nl63uqwa23u', 'c665a50e-577d-4ed3-a635-715c32df68a4', true, '2026-09-03 00:00:05.246144+00', '2026-09-17 00:57:13.684489+00', 'aq6se2pxdpoe', '3e0f0137-4b17-4803-ba3a-346b8bcebeb0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 79, 'f52wppawqmiw', 'c665a50e-577d-4ed3-a635-715c32df68a4', true, '2026-09-17 00:57:13.696921+00', '2026-09-17 04:24:23.709494+00', '2nl63uqwa23u', '3e0f0137-4b17-4803-ba3a-346b8bcebeb0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 80, 'ucyulhsam7fp', 'c665a50e-577d-4ed3-a635-715c32df68a4', false, '2026-09-17 04:24:23.726535+00', '2026-09-17 04:24:23.726535+00', 'f52wppawqmiw', '3e0f0137-4b17-4803-ba3a-346b8bcebeb0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 81, '6jffsoxomn42', 'c665a50e-577d-4ed3-a635-715c32df68a4', false, '2026-10-02 21:50:47.937892+00', '2026-10-02 21:50:47.937892+00', NULL, '4c6094e7-7812-4f80-93bd-32ab09383cdb');


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.schema_migrations (version) VALUES ('20171026211738');
INSERT INTO auth.schema_migrations (version) VALUES ('20171026211808');
INSERT INTO auth.schema_migrations (version) VALUES ('20171026211834');
INSERT INTO auth.schema_migrations (version) VALUES ('20180103212743');
INSERT INTO auth.schema_migrations (version) VALUES ('20180108183307');
INSERT INTO auth.schema_migrations (version) VALUES ('20180119214651');
INSERT INTO auth.schema_migrations (version) VALUES ('20180125194653');
INSERT INTO auth.schema_migrations (version) VALUES ('00');
INSERT INTO auth.schema_migrations (version) VALUES ('20210710035447');
INSERT INTO auth.schema_migrations (version) VALUES ('20210722035447');
INSERT INTO auth.schema_migrations (version) VALUES ('20210730183235');
INSERT INTO auth.schema_migrations (version) VALUES ('20210909172000');
INSERT INTO auth.schema_migrations (version) VALUES ('20210927181326');
INSERT INTO auth.schema_migrations (version) VALUES ('20211122151130');
INSERT INTO auth.schema_migrations (version) VALUES ('20211124214934');
INSERT INTO auth.schema_migrations (version) VALUES ('20211202183645');
INSERT INTO auth.schema_migrations (version) VALUES ('20220114185221');
INSERT INTO auth.schema_migrations (version) VALUES ('20220114185340');
INSERT INTO auth.schema_migrations (version) VALUES ('20220224000811');
INSERT INTO auth.schema_migrations (version) VALUES ('20220323170000');
INSERT INTO auth.schema_migrations (version) VALUES ('20220429102000');
INSERT INTO auth.schema_migrations (version) VALUES ('20220531120530');
INSERT INTO auth.schema_migrations (version) VALUES ('20220614074223');
INSERT INTO auth.schema_migrations (version) VALUES ('20220811173540');
INSERT INTO auth.schema_migrations (version) VALUES ('20221003041349');
INSERT INTO auth.schema_migrations (version) VALUES ('20221003041400');
INSERT INTO auth.schema_migrations (version) VALUES ('20221011041400');
INSERT INTO auth.schema_migrations (version) VALUES ('20221020193600');
INSERT INTO auth.schema_migrations (version) VALUES ('20221021073300');
INSERT INTO auth.schema_migrations (version) VALUES ('20221021082433');
INSERT INTO auth.schema_migrations (version) VALUES ('20221027105023');
INSERT INTO auth.schema_migrations (version) VALUES ('20221114143122');
INSERT INTO auth.schema_migrations (version) VALUES ('20221114143410');
INSERT INTO auth.schema_migrations (version) VALUES ('20221125140132');
INSERT INTO auth.schema_migrations (version) VALUES ('20221208132122');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195500');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195800');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195900');
INSERT INTO auth.schema_migrations (version) VALUES ('20230116124310');
INSERT INTO auth.schema_migrations (version) VALUES ('20230116124412');
INSERT INTO auth.schema_migrations (version) VALUES ('20230131181311');
INSERT INTO auth.schema_migrations (version) VALUES ('20230322519590');
INSERT INTO auth.schema_migrations (version) VALUES ('20230402418590');
INSERT INTO auth.schema_migrations (version) VALUES ('20230411005111');
INSERT INTO auth.schema_migrations (version) VALUES ('20230508135423');
INSERT INTO auth.schema_migrations (version) VALUES ('20230523124323');
INSERT INTO auth.schema_migrations (version) VALUES ('20230818113222');
INSERT INTO auth.schema_migrations (version) VALUES ('20230914180801');
INSERT INTO auth.schema_migrations (version) VALUES ('20231027141322');
INSERT INTO auth.schema_migrations (version) VALUES ('20231114161723');
INSERT INTO auth.schema_migrations (version) VALUES ('20231117164230');
INSERT INTO auth.schema_migrations (version) VALUES ('20240115144230');
INSERT INTO auth.schema_migrations (version) VALUES ('20240214120130');
INSERT INTO auth.schema_migrations (version) VALUES ('20240306115329');
INSERT INTO auth.schema_migrations (version) VALUES ('20240314092811');
INSERT INTO auth.schema_migrations (version) VALUES ('20240427152123');
INSERT INTO auth.schema_migrations (version) VALUES ('20240612123726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240729123726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240802193726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240806073726');
INSERT INTO auth.schema_migrations (version) VALUES ('20241009103726');
INSERT INTO auth.schema_migrations (version) VALUES ('20250717082212');
INSERT INTO auth.schema_migrations (version) VALUES ('20250731150234');
INSERT INTO auth.schema_migrations (version) VALUES ('20250804100000');
INSERT INTO auth.schema_migrations (version) VALUES ('20250901200500');
INSERT INTO auth.schema_migrations (version) VALUES ('20250903112500');
INSERT INTO auth.schema_migrations (version) VALUES ('20250904133000');
INSERT INTO auth.schema_migrations (version) VALUES ('20250925093508');
INSERT INTO auth.schema_migrations (version) VALUES ('20251007112900');
INSERT INTO auth.schema_migrations (version) VALUES ('20251104100000');
INSERT INTO auth.schema_migrations (version) VALUES ('20251111201300');
INSERT INTO auth.schema_migrations (version) VALUES ('20251201000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260115000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260121000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260219120000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260302000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260625000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260821000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260821010000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260824000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260824000001');
INSERT INTO auth.schema_migrations (version) VALUES ('20260831180000');


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: scim_users; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, name, sort_order, description) VALUES ('ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Hamburguesas', 1, 'Todas las hamburguesas incluyen una variedad de ingredientes y salsas específicas');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('8ac03b25-93dc-4b8b-b823-9677d87e3dee', 'Salchipapas', 2, 'Papas, salchicha y salsas de la casa');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Perros', 3, 'Long, ripio, queso y salsas de la casa');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Toppings', 4, 'Adiciones para tu pedido');


--
-- Data for Name: dishes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('bfd38a1f-ce00-4a3f-80df-d63290e5213c', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Sencilla', 'Carne de res, lechuga, ripio, queso mozzarella, salsas (tomate, mostaza, tártara) y papas a la francesa', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('87dac689-9253-41f4-862d-5487ad816081', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Mexicana', 'Carne de res, jalapeño ají vasco, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 6000, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('47fb02f6-4ebf-45b3-8350-e75d34b2be77', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Pollo', 'Carne de pollo, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 6000, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('1aefa3fc-e803-46d9-a466-368b8b128875', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Doble Carne', 'Doble carne de res, jamón, tocineta, ripio, lechuga, queso mozzarella, salsas (tártara, tomate, mostaza) y papas a la francesa', 12000, 4);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('bf522fa8-1011-48b9-8b0d-e1b3d6a48bc9', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Salchiburguer', 'Carne de res, lechuga, ripio, queso mozzarella, papa a la francesa, queso costeño y salsas (tártara, tomate, mostaza, piña)', 10000, 5);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('42731242-c50c-4349-82dd-0ca842e7d385', '8ac03b25-93dc-4b8b-b823-9677d87e3dee', 'Salchipapa', 'Papa a la francesa, salchicha, queso costeño, lechuga, papa ripio y salsas (tomate, tártara, piña)', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('f5066ca4-2346-4bad-9341-dfcfb5b85012', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Sencillo', 'Long (salchicha), ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('7d98d4cd-7f6c-4493-b61e-2a66defde2bf', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Planchiperro', 'Long (salchicha), carne de res, lechuga, ripio, queso costeño, queso mozzarella y salsas (tártara, piña, tomate)', 10000, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('75f774af-944f-40c3-a8cf-96cb9c0d9454', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Salchidog', 'Long (salchicha), ripio, lechuga, papas a la francesa, salchicha, queso costeño, queso mozzarella y salsas (tártara, piña, mostaza, tomate)', 10000, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('58ae68f1-834d-4658-b6e0-db6681d6b2d2', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Huevo Frito', 'Huevo frito adicional', 1000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('e99f0ea1-add0-4cec-b8ba-4b6cacfca078', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Jamón', 'Jamón adicional', 1500, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('cf5b4b1a-1c0b-41dd-92f1-fe2e5982ac6c', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Queso Mozzarella', 'Queso mozzarella adicional', 1500, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('7beb2d57-7138-41d4-b1c7-54b4b0ae89b3', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Tocineta', 'Tocineta adicional', 1500, 4);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('2efda1a1-24e7-483b-b617-015962e65410', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Cebolla Caramelizada', 'Cebolla caramelizada adicional', 1500, 5);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('ae28b246-ca3d-4d29-8a45-5c01f6ee652e', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Carne', 'Carne adicional', 3000, 6);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('fef876a3-7b62-41df-ac8d-2e8893d0e880', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Pollo', 'Pollo adicional', 3000, 7);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('67061a8f-9328-42f1-9a3c-c2ace471d317', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Mexicana', 'Mexicana adicional', 3000, 8);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('a8f8d2e6-baec-4f1b-98bd-cbfb24ae8d59', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Porción de Papas', 'Porción de papas a la francesa', 3000, 9);


--
-- Data for Name: waiters; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.waiters (id, auth_id, cedula, name, is_active, pin_changed, created_at, created_by, deleted_at) VALUES ('d12fe37d-aa88-4e58-ac41-f6893caf3fce', 'c665a50e-577d-4ed3-a635-715c32df68a4', '1235340086', 'Luis Mesero', true, true, '2026-07-10 23:40:37.469789+00', 'osiochico@gmail.com', NULL);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('d206845f-996f-4378-8118-8c9412205b63', 18, 'Luis Mesero', 'nueva', 32000, NULL, '2026-07-10 23:48:39.963569+00', 'Luis', '2026-07-10 23:49:43+00', 'admin', 'Yeison', 7000, 'd12fe37d-aa88-4e58-ac41-f6893caf3fce', NULL, 11);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('f012f46b-15ef-41b0-bed0-6c69d1e888b2', 13, 'Luis Mesero', 'finalizada', 37000, NULL, '2026-07-10 23:46:31.089621+00', 'Luis Mesero', '2026-09-02 03:17:50+00', 'waiter', NULL, 0, 'd12fe37d-aa88-4e58-ac41-f6893caf3fce', NULL, 10);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('efd7920c-f109-486e-bd41-b34b3a3a79f1', 1, 'Luis Mesero', 'nueva', 30000, NULL, '2026-09-03 00:02:03.514848+00', 'Luis Mesero', '2026-09-03 00:02:33+00', 'waiter', NULL, 0, 'd12fe37d-aa88-4e58-ac41-f6893caf3fce', NULL, 12);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('eec6353a-7177-4913-94a3-9bfcfc405f5a', 18, 'Luis Mesero', 'nueva', 15000, NULL, '2026-09-03 00:05:04.238521+00', NULL, NULL, NULL, 'Yeison', 4000, 'd12fe37d-aa88-4e58-ac41-f6893caf3fce', NULL, 14);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('ccc88f8b-c246-43bb-a5e8-5452a8069667', 18, 'Luis Mesero', 'nueva', 15000, NULL, '2026-09-03 00:05:04.238521+00', NULL, NULL, NULL, 'Yeison', 4000, 'd12fe37d-aa88-4e58-ac41-f6893caf3fce', NULL, 13);


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('cdf7fedd-2bac-4143-9e4b-afe461508c6f', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 13000, "item_count": 2, "table_number": 13}', '2026-07-10 23:46:31.56611+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('9c8aec2d-4859-455a-b71a-9c66c1127e68', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', 'status_changed', 'admin', 'Luis', 'nueva', 'en_cocina', '{}', '2026-07-10 23:46:51.076573+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('601b3fcf-714d-45a2-83a8-8024073cb35c', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', 'status_changed', 'waiter', 'Luis Mesero', 'en_cocina', 'servida', '{}', '2026-07-10 23:47:16.156956+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('e0201c3f-ddab-4a76-9ef1-2e222aaec490', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', 'additional_added', 'waiter', 'Luis Mesero', 'servida', 'adicional', '{"new_total": 37000, "item_count": 3, "added_items": [{"qty": 2, "name": "Mexicana", "notes": ["", ""]}, {"qty": 1, "name": "Doble Carne", "notes": [""]}], "additional_total": 24000, "additional_number": 1, "additional_desechables": 0}', '2026-07-10 23:47:33.022146+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('c934c5e3-bf33-4530-b415-d24242b25fa9', 'd206845f-996f-4378-8118-8c9412205b63', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 25000, "item_count": 3, "table_number": 18}', '2026-07-10 23:48:40.520289+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('e54a510b-f220-445d-9b79-ef77a1c682e1', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', 'status_changed', 'waiter', 'Luis Mesero', 'adicional', 'finalizada', '{}', '2026-09-02 03:17:50.51352+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('0ab9ad00-3db5-4460-ac15-451f6e08ec01', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 42000, "item_count": 6, "table_number": 1}', '2026-09-03 00:02:04.612501+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('b8fe7bbe-b322-4df4-86d3-139bfa3ff67d', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', 'updated', 'waiter', 'Luis Mesero', 'nueva', 'nueva', '{"added": 0, "total": 30000, "removed": 1, "updated": 0, "item_count": 5, "added_items": [], "table_number": 1, "removed_items": [{"qty": 1, "name": "Doble Carne"}], "updated_items": []}', '2026-09-03 00:02:33.88452+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('ddca1f7d-7364-4ffb-8b4c-810a2803f600', 'eec6353a-7177-4913-94a3-9bfcfc405f5a', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 15000, "item_count": 1, "table_number": 18}', '2026-09-03 00:05:05.035718+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('a0c10a2e-e4e0-45a0-b5a1-90e97f9ee88b', 'ccc88f8b-c246-43bb-a5e8-5452a8069667', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 15000, "item_count": 1, "table_number": 18}', '2026-09-03 00:05:05.047713+00', 'c665a50e-577d-4ed3-a635-715c32df68a4');


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('4b5759bf-2866-4d8a-8907-749c0947142f', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', '87dac689-9253-41f4-862d-5487ad816081', 'Mexicana', 6000, 2, '["Sin salsas", "Sin lechuga, Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('bbca2cb4-f44d-495b-877b-cf803261a1ab', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', '87dac689-9253-41f4-862d-5487ad816081', 'Mexicana', 6000, 2, NULL, NULL, true, 1);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('8fe02835-1117-4f43-bac9-5e004395552f', 'f012f46b-15ef-41b0-bed0-6c69d1e888b2', '1aefa3fc-e803-46d9-a466-368b8b128875', 'Doble Carne', 12000, 1, NULL, NULL, true, 1);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('07fb92d4-7ea2-4a81-b9ef-293742b4538a', 'd206845f-996f-4378-8118-8c9412205b63', '47fb02f6-4ebf-45b3-8350-e75d34b2be77', 'Pollo', 6000, 2, '["Para llevar", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('3437b995-0ad0-46f1-b4a8-9145beba01b1', 'd206845f-996f-4378-8118-8c9412205b63', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('13b491e2-b6aa-4b0d-bf59-e919ab3a6448', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', 'bfd38a1f-ce00-4a3f-80df-d63290e5213c', 'Sencilla', 5000, 1, NULL, NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('0f54c740-ba3e-4402-afc4-0d7d87741d63', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', '42731242-c50c-4349-82dd-0ca842e7d385', 'Salchipapa', 5000, 2, NULL, NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('f1c423b0-8cd5-48ee-87e9-ba2c02fbb632', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 1, NULL, NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('d962cd37-0242-4d8e-ae2b-dbf5f667f230', 'efd7920c-f109-486e-bd41-b34b3a3a79f1', 'f5066ca4-2346-4bad-9341-dfcfb5b85012', 'Sencillo', 5000, 1, NULL, NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('fb4a95db-abdf-4693-bd3f-796c802c8074', 'ccc88f8b-c246-43bb-a5e8-5452a8069667', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('5a172dad-cb73-4e83-810c-67515197fe6a', 'eec6353a-7177-4913-94a3-9bfcfc405f5a', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 1, '["Para llevar"]', NULL, false, NULL);


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: messages_2026_10_01; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_10_02; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_10_03; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_10_04; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_10_05; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116024918, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116045059, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116050929, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116051442, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116212300, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116213355, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116213934, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116214523, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211122062447, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211124070109, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211202204204, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211202204605, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211210212804, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211228014915, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220107221237, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220228202821, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220312004840, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220603231003, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220603232444, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220615214548, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220712093339, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220908172859, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220916233421, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230119133233, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230128025114, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230128025212, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230227211149, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230228184745, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230308225145, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230328144023, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231018144023, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144023, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144024, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144025, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240108234812, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240109165339, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240227174441, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240311171622, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240321100241, '2026-06-26 21:56:15');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240401105812, '2026-06-26 21:56:15');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240418121054, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240523004032, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240618124746, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240801235015, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240805133720, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240827160934, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240919163303, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240919163305, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241019105805, '2026-06-26 21:56:18');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241030150047, '2026-06-26 21:56:18');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241108114728, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241121104152, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241130184212, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241220035512, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241220123912, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241224161212, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250107150512, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250110162412, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250123174212, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250128220012, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250506224012, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250523164012, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250714121412, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250905041441, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251103001201, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251120212548, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251120215549, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260218120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260326120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260514120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260527120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260528120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260603120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260605120000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260606110000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260616120000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260624120000, '2026-06-26 21:56:25');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260626120000, '2026-07-06 21:27:50');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260706120000, '2026-07-08 04:38:59');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260707120000, '2026-07-15 04:31:31');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260709120000, '2026-07-15 04:31:31');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260714120000, '2026-09-17 00:57:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260827120000, '2026-09-17 00:57:18');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260914120000, '2026-10-02 21:50:50');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260916120000, '2026-10-02 21:50:50');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260922120000, '2026-10-02 21:50:50');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260925120000, '2026-10-02 21:50:51');


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (0, 'create-migrations-table', 'e18db593bcde2aca2a408c4d1100f6abba2195df', '2026-06-26 19:34:26.745323');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (1, 'initialmigration', '6ab16121fbaa08bbd11b712d05f358f9b555d777', '2026-06-26 19:34:26.781197');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (2, 'storage-schema', 'f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd', '2026-06-26 19:34:26.786123');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (3, 'pathtoken-column', '2cb1b0004b817b29d5b0a971af16bafeede4b70d', '2026-06-26 19:34:26.814651');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (4, 'add-migrations-rls', '427c5b63fe1c5937495d9c635c263ee7a5905058', '2026-06-26 19:34:26.831082');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (5, 'add-size-functions', '79e081a1455b63666c1294a440f8ad4b1e6a7f84', '2026-06-26 19:34:26.835546');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (6, 'change-column-name-in-get-size', 'ded78e2f1b5d7e616117897e6443a925965b30d2', '2026-06-26 19:34:26.840646');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (7, 'add-rls-to-buckets', 'e7e7f86adbc51049f341dfe8d30256c1abca17aa', '2026-06-26 19:34:26.845542');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (8, 'add-public-to-buckets', 'fd670db39ed65f9d08b01db09d6202503ca2bab3', '2026-06-26 19:34:26.849868');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (9, 'fix-search-function', 'af597a1b590c70519b464a4ab3be54490712796b', '2026-06-26 19:34:26.854819');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (10, 'search-files-search-function', 'b595f05e92f7e91211af1bbfe9c6a13bb3391e16', '2026-06-26 19:34:26.859362');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (11, 'add-trigger-to-auto-update-updated_at-column', '7425bdb14366d1739fa8a18c83100636d74dcaa2', '2026-06-26 19:34:26.865893');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (12, 'add-automatic-avif-detection-flag', '8e92e1266eb29518b6a4c5313ab8f29dd0d08df9', '2026-06-26 19:34:26.871146');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (13, 'add-bucket-custom-limits', 'cce962054138135cd9a8c4bcd531598684b25e7d', '2026-06-26 19:34:26.875645');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (14, 'use-bytes-for-max-size', '941c41b346f9802b411f06f30e972ad4744dad27', '2026-06-26 19:34:26.880341');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (15, 'add-can-insert-object-function', '934146bc38ead475f4ef4b555c524ee5d66799e5', '2026-06-26 19:34:26.908682');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (16, 'add-version', '76debf38d3fd07dcfc747ca49096457d95b1221b', '2026-06-26 19:34:26.913274');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (17, 'drop-owner-foreign-key', 'f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101', '2026-06-26 19:34:26.917804');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (18, 'add_owner_id_column_deprecate_owner', 'e7a511b379110b08e2f214be852c35414749fe66', '2026-06-26 19:34:26.922334');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (19, 'alter-default-value-objects-id', '02e5e22a78626187e00d173dc45f58fa66a4f043', '2026-06-26 19:34:26.929729');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (20, 'list-objects-with-delimiter', 'cd694ae708e51ba82bf012bba00caf4f3b6393b7', '2026-06-26 19:34:26.934267');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (21, 's3-multipart-uploads', '8c804d4a566c40cd1e4cc5b3725a664a9303657f', '2026-06-26 19:34:26.940364');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (22, 's3-multipart-uploads-big-ints', '9737dc258d2397953c9953d9b86920b8be0cdb73', '2026-06-26 19:34:26.95579');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (23, 'optimize-search-function', '9d7e604cddc4b56a5422dc68c9313f4a1b6f132c', '2026-06-26 19:34:26.965583');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (24, 'operation-function', '8312e37c2bf9e76bbe841aa5fda889206d2bf8aa', '2026-06-26 19:34:26.971739');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (25, 'custom-metadata', 'd974c6057c3db1c1f847afa0e291e6165693b990', '2026-06-26 19:34:26.976214');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (26, 'objects-prefixes', '215cabcb7f78121892a5a2037a09fedf9a1ae322', '2026-06-26 19:34:26.980919');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (27, 'search-v2', '859ba38092ac96eb3964d83bf53ccc0b141663a6', '2026-06-26 19:34:26.985132');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (28, 'object-bucket-name-sorting', 'c73a2b5b5d4041e39705814fd3a1b95502d38ce4', '2026-06-26 19:34:26.989511');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (29, 'create-prefixes', 'ad2c1207f76703d11a9f9007f821620017a66c21', '2026-06-26 19:34:26.993794');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (30, 'update-object-levels', '2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6', '2026-06-26 19:34:26.997923');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (31, 'objects-level-index', 'b40367c14c3440ec75f19bbce2d71e914ddd3da0', '2026-06-26 19:34:27.001904');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (32, 'backward-compatible-index-on-objects', 'e0c37182b0f7aee3efd823298fb3c76f1042c0f7', '2026-06-26 19:34:27.006984');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (33, 'backward-compatible-index-on-prefixes', 'b480e99ed951e0900f033ec4eb34b5bdcb4e3d49', '2026-06-26 19:34:27.01135');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (34, 'optimize-search-function-v1', 'ca80a3dc7bfef894df17108785ce29a7fc8ee456', '2026-06-26 19:34:27.015382');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (35, 'add-insert-trigger-prefixes', '458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc', '2026-06-26 19:34:27.019583');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (36, 'optimise-existing-functions', '6ae5fca6af5c55abe95369cd4f93985d1814ca8f', '2026-06-26 19:34:27.023708');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (37, 'add-bucket-name-length-trigger', '3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1', '2026-06-26 19:34:27.027789');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (38, 'iceberg-catalog-flag-on-buckets', '02716b81ceec9705aed84aa1501657095b32e5c5', '2026-06-26 19:34:27.033042');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (39, 'add-search-v2-sort-support', '6706c5f2928846abee18461279799ad12b279b78', '2026-06-26 19:34:27.043697');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (40, 'fix-prefix-race-conditions-optimized', '7ad69982ae2d372b21f48fc4829ae9752c518f6b', '2026-06-26 19:34:27.047592');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (41, 'add-object-level-update-trigger', '07fcf1a22165849b7a029deed059ffcde08d1ae0', '2026-06-26 19:34:27.051556');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (42, 'rollback-prefix-triggers', '771479077764adc09e2ea2043eb627503c034cd4', '2026-06-26 19:34:27.05559');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (43, 'fix-object-level', '84b35d6caca9d937478ad8a797491f38b8c2979f', '2026-06-26 19:34:27.059651');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (44, 'vector-bucket-type', '99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3', '2026-06-26 19:34:27.06456');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (45, 'vector-buckets', '049e27196d77a7cb76497a85afae669d8b230953', '2026-06-26 19:34:27.069367');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (46, 'buckets-objects-grants', 'fedeb96d60fefd8e02ab3ded9fbde05632f84aed', '2026-06-26 19:34:27.080682');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (47, 'iceberg-table-metadata', '649df56855c24d8b36dd4cc1aeb8251aa9ad42c2', '2026-06-26 19:34:27.085353');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (48, 'iceberg-catalog-ids', 'e0e8b460c609b9999ccd0df9ad14294613eed939', '2026-06-26 19:34:27.089463');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (49, 'buckets-objects-grants-postgres', '072b1195d0d5a2f888af6b2302a1938dd94b8b3d', '2026-06-26 19:34:27.105436');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (50, 'search-v2-optimised', '6323ac4f850aa14e7387eb32102869578b5bd478', '2026-06-26 19:34:27.110761');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (51, 'index-backward-compatible-search', '2ee395d433f76e38bcd3856debaf6e0e5b674011', '2026-06-26 19:34:27.128929');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (52, 'drop-not-used-indexes-and-functions', '5cc44c8696749ac11dd0dc37f2a3802075f3a171', '2026-06-26 19:34:27.130805');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (53, 'drop-index-lower-name', 'd0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854', '2026-06-26 19:34:27.139991');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (54, 'drop-index-object-level', '6289e048b1472da17c31a7eba1ded625a6457e67', '2026-06-26 19:34:27.142898');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (55, 'prevent-direct-deletes', '262a4798d5e0f2e7c8970232e03ce8be695d5819', '2026-06-26 19:34:27.144782');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (56, 'fix-optimized-search-function', 'b823ed1e418101032fa01374edc9a436e54e3ed4', '2026-06-26 19:34:27.150183');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (57, 's3-multipart-uploads-metadata', 'f127886e00d1b374fadbc7c6b31e09336aad5287', '2026-06-26 19:34:27.155535');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (58, 'operation-ergonomics', '00ca5d483b3fe0d522133d9002ccc5df98365120', '2026-06-26 19:34:27.160008');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (59, 'drop-unused-functions', '38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4', '2026-06-26 19:34:27.164915');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (60, 'optimize-existing-functions-again', 'db35e1c91a9201e59f4fef8d972c2f277d68b157', '2026-06-26 19:34:27.169547');


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: -
--

INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627170000', '{"alter table order_items alter column notes type jsonb","alter table order_items add constraint notes_is_text_array check (notes is null or jsonb_typeof(notes) = ''array'')"}', 'notes_to_jsonb');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627160152', '{"-- ============================================================
-- Punto 5 — POC schema
-- Run this in the Supabase SQL editor.
-- Object names and comments are in English.
-- Seed data (category/dish names, descriptions) is in Spanish
-- because that is the user-facing language of the app.
-- ============================================================

-- Categories (e.g. Hamburguesas, Salchipapas y Perros, Adicionales)
create table if not exists categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text not null default '''',  -- short subtitle shown in POS (e.g. \"Hamburguesas artesanales\")
  sort_order  int  not null default 0
)","-- Dishes within a category
create table if not exists dishes (
  id           uuid primary key default gen_random_uuid(),
  category_id  uuid not null references categories(id) on delete cascade,
  name         text not null,
  description  text not null default '''',
  price        int  not null default 0,   -- price in Colombian pesos
  sort_order   int  not null default 0
)","create index if not exists idx_dishes_category on dishes(category_id)","-- Orders placed by waiters from the POS
create table if not exists orders (
  id              uuid primary key default gen_random_uuid(),
  table_number    int  not null,              -- table number
  waiter_name     text not null,              -- waiter name (no auth in POC)
  status          text not null default ''nueva''
    check (status in (''nueva'',''en_cocina'',''lista'',''servida'')),
  total           int  not null default 0,    -- total in pesos
  notes           text,
  created_at      timestamptz not null default now(),
  -- Audit tracking: who last touched this order
  updated_by      text,                        -- name of the last actor
  updated_at      timestamptz,                 -- when it was last updated
  updated_by_type text check (updated_by_type in (''waiter'',''admin'',''system''))
)","create index if not exists idx_orders_created on orders(created_at desc)","create index if not exists idx_orders_status  on orders(status)","-- Line items per order
create table if not exists order_items (
  id         uuid primary key default gen_random_uuid(),
  order_id   uuid not null references orders(id) on delete cascade,
  dish_id    uuid references dishes(id),
  dish_name     text not null,               -- snapshot of dish name at order time
  price         int  not null,               -- snapshot of price at order time
  quantity      int  not null default 1,
  notes         text                          -- per-item instructions (migrated to jsonb in later migration)
)","create index if not exists idx_order_items_order on order_items(order_id)","-- ============================================================
-- Audit trail — every action on an order is logged here.
-- This gives us full traceability: who did what, when, and
-- what changed (from/to for status transitions, metadata for
-- prints and other events).
-- ============================================================
create table if not exists order_events (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references orders(id) on delete cascade,
  event_type  text not null check (event_type in
    (''created'',''status_changed'',''printed'',''updated'',''cancelled'')),
  actor_type  text not null check (actor_type in (''waiter'',''admin'',''system'')),
  actor_name  text not null,               -- waiter name or ''admin''
  from_status text,                         -- previous status (for status_changed)
  to_status   text,                         -- new status (for status_changed)
  metadata    jsonb not null default ''{}'',  -- flexible: print count, changed fields, etc.
  created_at  timestamptz not null default now()
)","create index if not exists idx_order_events_order on order_events(order_id, created_at desc)","-- ============================================================
-- Push subscriptions — one waiter can have multiple devices
-- ============================================================
create table if not exists push_subscriptions (
  id            uuid primary key default gen_random_uuid(),
  waiter_name   text not null,                          -- waiter name (links to orders.waiter_name)
  endpoint      text not null,                          -- push service endpoint URL (unique per device/browser)
  p256dh        text not null,                          -- ECDH public key from browser
  auth          text not null,                          -- auth secret from browser
  created_at    timestamptz not null default now()
)","create index if not exists idx_push_subs_waiter on push_subscriptions(waiter_name)","create unique index if not exists idx_push_subs_endpoint on push_subscriptions(endpoint)","-- ============================================================
-- RLS — POC: allow all operations with the anon key.
-- Tighten before production.
--
-- Production RLS should enforce:
--   - Waiters can only UPDATE orders where waiter_name = auth.uid()
--     (i.e. they can only modify orders they created).
--   - Admins can UPDATE any order.
--   - Waiters can only INSERT order_events for their own orders.
-- The app-level check (isOrderOwner in lib/utils.ts) covers this
-- for the POC, but RLS is the real enforcement layer.
-- ============================================================

-- GRANTs — Supabase''s new default (2026+) does NOT auto-expose tables
-- to the anon/authenticated roles. RLS policies alone are not enough;
-- the underlying table privileges must be granted explicitly.
grant select on categories    to anon, authenticated","grant select on dishes        to anon, authenticated","grant select on orders        to anon, authenticated","grant insert on orders        to anon, authenticated","grant update on orders        to anon, authenticated","grant select on order_items   to anon, authenticated","grant insert on order_items   to anon, authenticated","grant update on order_items   to anon, authenticated","grant delete on order_items   to anon, authenticated","grant select on order_events  to anon, authenticated","grant insert on order_events  to anon, authenticated","grant insert on push_subscriptions to anon, authenticated","grant delete on push_subscriptions to anon, authenticated","grant select on push_subscriptions to anon, authenticated","alter table categories    enable row level security","alter table dishes        enable row level security","alter table orders        enable row level security","alter table order_items   enable row level security","alter table order_events  enable row level security","alter table push_subscriptions enable row level security","create policy \"poc_read_categories\"  on categories  for select using (true)","create policy \"poc_read_dishes\"      on dishes      for select using (true)","create policy \"poc_read_orders\"      on orders      for select using (true)","create policy \"poc_insert_orders\"    on orders      for insert with check (true)","create policy \"poc_update_orders\"    on orders      for update using (true)","create policy \"poc_delete_orders\"    on orders      for delete using (true)","create policy \"poc_read_order_items\"   on order_items  for select using (true)","create policy \"poc_insert_order_items\" on order_items  for insert with check (true)","create policy \"poc_update_order_items\" on order_items  for update using (true)","create policy \"poc_delete_order_items\" on order_items  for delete using (true)","create policy \"poc_read_order_events\"  on order_events for select using (true)","create policy \"poc_insert_order_events\" on order_events for insert with check (true)","create policy \"poc_insert_push_subs\" on push_subscriptions for insert with check (true)","create policy \"poc_delete_push_subs\" on push_subscriptions for delete using (true)","create policy \"poc_read_push_subs\"   on push_subscriptions for select using (true)","-- ============================================================
-- Realtime — enable publication for the tables we subscribe to
-- ============================================================
alter publication supabase_realtime add table orders","alter publication supabase_realtime add table order_items","alter publication supabase_realtime add table order_events","-- ============================================================
-- Seed data — real menu
-- ============================================================
insert into categories (name, description, sort_order) values
  (''Hamburguesas'', ''Todas las hamburguesas incluyen una variedad de ingredientes y salsas específicas'', 1),
  (''Salchipapas'', ''Papas, salchicha y salsas de la casa'', 2),
  (''Perros'', ''Long, ripio, queso y salsas de la casa'', 3),
  (''Toppings'', ''Adiciones para tu pedido'', 4)
on conflict do nothing","-- Hamburguesas
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Sencilla'',      ''Carne de res, lechuga, ripio, queso mozzarella, salsas (tomate, mostaza, tártara) y papas a la francesa'', 5000, 1),
  (''Mexicana'',      ''Carne de res, jalapeño ají vasco, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 6000, 2),
  (''Pollo'',         ''Carne de pollo, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 6000, 3),
  (''Doble Carne'',   ''Doble carne de res, jamón, tocineta, ripio, lechuga, queso mozzarella, salsas (tártara, tomate, mostaza) y papas a la francesa'', 12000, 4),
  (''Salchiburguer'', ''Carne de res, lechuga, ripio, queso mozzarella, papa a la francesa, queso costeño y salsas (tártara, tomate, mostaza, piña)'', 10000, 5)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Hamburguesas''
on conflict do nothing","-- Salchipapas
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Salchipapa'', ''Papa a la francesa, salchicha, queso costeño, lechuga, papa ripio y salsas (tomate, tártara, piña)'', 5000, 1)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Salchipapas''
on conflict do nothing","-- Perros
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Sencillo'',     ''Long (salchicha), ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 5000, 1),
  (''Planchiperro'', ''Long (salchicha), carne de res, lechuga, ripio, queso costeño, queso mozzarella y salsas (tártara, piña, tomate)'', 10000, 2),
  (''Salchidog'',    ''Long (salchicha), ripio, lechuga, papas a la francesa, salchicha, queso costeño, queso mozzarella y salsas (tártara, piña, mostaza, tomate)'', 10000, 3)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Perros''
on conflict do nothing","-- Toppings (Adiciones)
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Huevo Frito'',           ''Huevo frito adicional'', 1000, 1),
  (''Jamón'',                 ''Jamón adicional'', 1500, 2),
  (''Queso Mozzarella'',      ''Queso mozzarella adicional'', 1500, 3),
  (''Tocineta'',              ''Tocineta adicional'', 1500, 4),
  (''Cebolla Caramelizada'',  ''Cebolla caramelizada adicional'', 1500, 5),
  (''Carne'',                 ''Carne adicional'', 3000, 6),
  (''Pollo'',                 ''Pollo adicional'', 3000, 7),
  (''Mexicana'',              ''Mexicana adicional'', 3000, 8),
  (''Porción de Papas'',      ''Porción de papas a la francesa'', 3000, 9)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Toppings''
on conflict do nothing"}', 'initial_schema');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627180000', '{"-- Add delivery_name column for delivery/to-go orders (table 18)
-- When an order is for \"Domicilio\", this stores the customer name or description
-- so the kitchen knows who it''s for.
ALTER TABLE orders ADD COLUMN delivery_name text","-- Delivery orders (table 18) should have a delivery_name
-- We enforce this at the app level, not via DB constraint, to avoid
-- blocking existing orders."}', 'add_delivery_name');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627190000', '{"-- Add delivery_fee column for admin-set delivery charge per order
-- This is separate from the desechables ($1000/dish) which is automatic
ALTER TABLE orders ADD COLUMN delivery_fee int not null default 0"}', 'add_delivery_fee');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260628060000', '{"-- ============================================================
-- Authentication: waiters table + waiter_id/actor_id columns
--
-- This migration adds:
--   1. `waiters` table — links Supabase Auth accounts to waiter profiles
--   2. `orders.waiter_id` — FK to waiters.id (replaces name-only identification)
--   3. `order_events.actor_id` — FK to auth.users for real audit trail
--   4. Tightened RLS policies (replacing the POC \"allow all\" policies)
--
-- Auth accounts are created via the admin UI (Supabase client),
-- not via this migration. The admin account is created manually
-- via the Supabase dashboard or a setup script.
-- ============================================================

-- ============================================================
-- Waiters table
-- ============================================================
create table if not exists waiters (
  id           uuid primary key default gen_random_uuid(),
  auth_id      uuid not null references auth.users(id) on delete cascade,
  cedula       text not null unique,              -- Colombian national ID
  name         text not null,                      -- display name
  is_active    boolean not null default true,      -- admin can deactivate
  pin_changed  boolean not null default false,     -- false = must change PIN on first login
  created_at   timestamptz not null default now(),
  created_by   text                                -- admin email who created this waiter
)","create index if not exists idx_waiters_auth_id on waiters(auth_id)","create index if not exists idx_waiters_cedula on waiters(cedula)","create index if not exists idx_waiters_active on waiters(is_active) where is_active = true","-- ============================================================
-- Add waiter_id to orders (NOT NULL — every order must have a waiter)
-- Existing test orders are deleted first since they have no waiter_id.
-- ============================================================
alter table orders add column if not exists waiter_id uuid references waiters(id) on delete restrict","-- Delete existing orders that have no waiter_id (test data from POC)
delete from order_items where order_id in (select id from orders where waiter_id is null)","delete from order_events where order_id in (select id from orders where waiter_id is null)","delete from orders where waiter_id is null","-- Now enforce NOT NULL
alter table orders alter column waiter_id set not null","create index if not exists idx_orders_waiter_id on orders(waiter_id)","-- ============================================================
-- Add actor_id to order_events (nullable — system events may not have an actor)
-- ============================================================
alter table order_events add column if not exists actor_id uuid references auth.users(id) on delete set null","create index if not exists idx_order_events_actor_id on order_events(actor_id) where actor_id is not null","-- ============================================================
-- RLS — replace POC \"allow all\" policies with real enforcement
-- ============================================================

-- Drop all existing POC policies
drop policy if exists \"poc_read_categories\"  on categories","drop policy if exists \"poc_read_dishes\"      on dishes","drop policy if exists \"poc_read_orders\"      on orders","drop policy if exists \"poc_insert_orders\"    on orders","drop policy if exists \"poc_update_orders\"    on orders","drop policy if exists \"poc_delete_orders\"    on orders","drop policy if exists \"poc_read_order_items\"   on order_items","drop policy if exists \"poc_insert_order_items\" on order_items","drop policy if exists \"poc_update_order_items\" on order_items","drop policy if exists \"poc_delete_order_items\" on order_items","drop policy if exists \"poc_read_order_events\"  on order_events","drop policy if exists \"poc_insert_order_events\" on order_events","drop policy if exists \"poc_insert_push_subs\" on push_subscriptions","drop policy if exists \"poc_delete_push_subs\" on push_subscriptions","drop policy if exists \"poc_read_push_subs\"   on push_subscriptions","-- Helper function: check if current user is admin
-- Admins have app_metadata.role = ''admin''
create or replace function is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'',
    false
  );
$$","-- Helper function: get current waiter''s id
-- Looks up waiters table by auth.uid()
create or replace function current_waiter_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select id from waiters where auth_id = auth.uid() and is_active = true;
$$","-- Helper function: check if current user is an active waiter
create or replace function is_waiter()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from waiters where auth_id = auth.uid() and is_active = true);
$$","-- Helper function: check if current waiter owns an order
create or replace function is_order_owner(order_row orders)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select order_row.waiter_id = current_waiter_id();
$$","-- ============================================================
-- Categories & Dishes — read-only for authenticated users
-- ============================================================
create policy \"read_categories\" on categories
  for select to authenticated using (true)","create policy \"read_dishes\" on dishes
  for select to authenticated using (true)","-- ============================================================
-- Waiters — read-only for authenticated, write via service_role only
-- (admin manages waiters through the edge function using service role)
-- ============================================================
alter table waiters enable row level security","create policy \"read_waiters\" on waiters
  for select to authenticated using (true)","create policy \"service_role_all_waiters\" on waiters
  for all to service_role using (true) with check (true)","-- Security definer function for public waiter lookup by cédula.
-- The login page needs to verify a cédula exists before showing the PIN
-- keypad, but the user has no session yet. This function exposes only
-- cedula, name, and is_active for active waiters.
create or replace function public.lookup_waiter_by_cedula(p_cedula text)
returns table(cedula text, name text, is_active boolean)
language sql
stable
security definer
set search_path = public
as $$
  select cedula, name, is_active
  from public.waiters
  where cedula = p_cedula and is_active = true;
$$","grant execute on function public.lookup_waiter_by_cedula(text) to anon, authenticated","-- ============================================================
-- Orders — admin: all | waiter: own orders only
-- ============================================================
create policy \"orders_select\" on orders
  for select to authenticated using (
    is_admin() or is_order_owner(orders)
  )","create policy \"orders_insert\" on orders
  for insert to authenticated with check (
    is_admin() or waiter_id = current_waiter_id()
  )","create policy \"orders_update\" on orders
  for update to authenticated using (
    is_admin() or is_order_owner(orders)
  ) with check (
    is_admin() or is_order_owner(orders)
  )","create policy \"orders_delete\" on orders
  for delete to authenticated using (is_admin())","-- ============================================================
-- Order items — admin: all | waiter: own order''s items only
-- ============================================================
create policy \"order_items_select\" on order_items
  for select to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_insert\" on order_items
  for insert to authenticated with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_update\" on order_items
  for update to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  ) with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_delete\" on order_items
  for delete to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","-- ============================================================
-- Order events — admin: read all | waiter: read own, insert own
-- ============================================================
create policy \"order_events_select\" on order_events
  for select to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_events.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_events_insert\" on order_events
  for insert to authenticated with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_events.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","-- ============================================================
-- Waiters — admin: all | waiter: read own row only
-- ============================================================
create policy \"waiters_select\" on waiters
  for select to authenticated using (
    is_admin() or auth_id = auth.uid()
  )","create policy \"waiters_insert\" on waiters
  for insert to authenticated with check (is_admin())","create policy \"waiters_update\" on waiters
  for update to authenticated using (
    is_admin() or auth_id = auth.uid()
  ) with check (
    is_admin() or auth_id = auth.uid()
  )","create policy \"waiters_delete\" on waiters
  for delete to authenticated using (is_admin())","-- ============================================================
-- Push subscriptions — waiter: manage own only
-- ============================================================
create policy \"push_subs_select\" on push_subscriptions
  for select to authenticated using (
    is_admin() or exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
    )
  )","create policy \"push_subs_insert\" on push_subscriptions
  for insert to authenticated with check (
    exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
      and w.is_active = true
    )
  )","create policy \"push_subs_delete\" on push_subscriptions
  for delete to authenticated using (
    exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
    )
  )","-- ============================================================
-- GRANTs — re-grant with authenticated role (drop anon)
-- ============================================================
revoke select on categories from anon","revoke select on dishes from anon","revoke select on orders from anon","revoke insert on orders from anon","revoke update on orders from anon","revoke select on order_items from anon","revoke insert on order_items from anon","revoke update on order_items from anon","revoke delete on order_items from anon","revoke select on order_events from anon","revoke insert on order_events from anon","revoke insert on push_subscriptions from anon","revoke delete on push_subscriptions from anon","revoke select on push_subscriptions from anon","grant select on categories    to authenticated","grant select on dishes        to authenticated","grant select on orders        to authenticated","grant insert on orders        to authenticated","grant update on orders        to authenticated","grant delete on orders        to authenticated","grant select on order_items   to authenticated","grant insert on order_items   to authenticated","grant update on order_items   to authenticated","grant delete on order_items   to authenticated","grant select on order_events  to authenticated","grant insert on order_events  to authenticated","grant select on waiters       to authenticated","grant insert on waiters       to authenticated","grant update on waiters       to authenticated","grant delete on waiters       to authenticated","grant select on push_subscriptions to authenticated","grant insert on push_subscriptions to authenticated","grant delete on push_subscriptions to authenticated","-- Grant execute on helper functions
grant execute on function is_admin() to authenticated","grant execute on function is_waiter() to authenticated","grant execute on function current_waiter_id() to authenticated","grant execute on function is_order_owner(orders) to authenticated"}', 'auth_and_rls');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260628170000', '{"-- Order adicionals — allows adding items to a served order
-- without creating a new order. Items are flagged with is_additional
-- and grouped by additional_number (round 1, 2, etc.)

-- Add columns to order_items
alter table order_items
  add column if not exists is_additional boolean not null default false,
  add column if not exists additional_number int","-- Index for filtering additional items
create index if not exists idx_order_items_additional
  on order_items (order_id, is_additional, additional_number)"}', 'order_additionals');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629060000', '{"-- Add ''delivery_fee_set'' to the order_events event_type check constraint.
-- This event is logged when an admin sets the delivery fee for an order.

ALTER TABLE order_events DROP CONSTRAINT IF EXISTS order_events_event_type_check","ALTER TABLE order_events ADD CONSTRAINT order_events_event_type_check
  check (event_type in (''created'',''status_changed'',''printed'',''updated'',''cancelled'',''additional_added'',''delivery_fee_set''))"}', 'add_delivery_fee_set_event_type');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629120000', '{"-- Rename order statuses: lista → servida, servida → finalizada
--
-- \"lista\" (kitchen ready) is renamed to \"servida\" (food on table)
-- \"servida\" (was terminal) is renamed to \"finalizada\" (payment confirmed)
--
-- Order matters: rename servida → finalizada FIRST to free up \"servida\",
-- then rename lista → servida.
-- The check constraint must be dropped before the renames (it would block
-- the UPDATE) and re-added with the new allowed values at the end.

-- 1. Drop check constraint (it would block status values not in the old list)
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check","-- 2. Rename servida → finalizada (orders + order_events)
UPDATE orders SET status = ''finalizada'' WHERE status = ''servida''","UPDATE order_events SET from_status = ''finalizada'' WHERE from_status = ''servida''","UPDATE order_events SET to_status = ''finalizada'' WHERE to_status = ''servida''","-- 3. Rename lista → servida (now safe, no conflict)
UPDATE orders SET status = ''servida'' WHERE status = ''lista''","UPDATE order_events SET from_status = ''servida'' WHERE from_status = ''lista''","UPDATE order_events SET to_status = ''servida'' WHERE to_status = ''lista''","-- 4. Re-add check constraint with new allowed values
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  check (status in (''nueva'',''en_cocina'',''servida'',''finalizada'',''adicional''))"}', 'rename_status_lista_to_servida');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629160000', '{"-- Add soft delete columns to waiters and orders tables.
--
-- Waiters: `deleted_at` allows reusing a cédula after soft delete.
--   The unique constraint on `cedula` is replaced with a partial unique
--   index that only applies to non-deleted rows, so a new waiter can be
--   created with the same cédula as a previously deleted one.
--
-- Orders: `deleted_at` allows admin to remove orders from the dashboard
--   without losing the audit trail.

-- 1. Waiters: add deleted_at column
alter table waiters add column if not exists deleted_at timestamptz","-- 2. Waiters: replace unique constraint on cedula with partial unique index
--    Drop the old constraint and create a new one that only applies to
--    non-deleted rows. This allows reusing a cédula after soft delete.
alter table waiters drop constraint if exists waiters_cedula_key","create unique index if not exists waiters_cedula_unique_active
  on waiters (cedula) where deleted_at is null","-- 3. Orders: add deleted_at column
alter table orders add column if not exists deleted_at timestamptz","-- 4. Orders: index for filtering out soft-deleted orders
create index if not exists idx_orders_active
  on orders (created_at) where deleted_at is null"}', 'add_soft_delete');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629170000', '{"-- Fix RLS policies and helper functions for soft-delete correctness.
--
-- Issues found:
-- 1. orders_select RLS allows waiters to see soft-deleted orders
-- 2. waiters_select RLS allows deleted waiters to read their own profile
-- 3. lookup_waiter_by_cedula doesn''t filter deleted_at (defense in depth)
-- 4. current_waiter_id() doesn''t filter deleted_at (defense in depth)

-- 1. orders_select: waiters should only see non-deleted orders
drop policy if exists orders_select on orders","create policy orders_select on orders
  for select
  using (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )","-- 2. waiters_select: deleted waiters should not be able to read their profile
drop policy if exists waiters_select on waiters","create policy waiters_select on waiters
  for select
  using (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )","-- 2b. orders_update: waiters should not be able to update soft-deleted orders
drop policy if exists orders_update on orders","create policy orders_update on orders
  for update
  using (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )
  with check (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )","-- 2c. waiters_update: deleted waiters should not be able to update their profile
--     (e.g. reactivate themselves by setting is_active = true)
drop policy if exists waiters_update on waiters","create policy waiters_update on waiters
  for update
  using (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )
  with check (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )","-- 3. lookup_waiter_by_cedula: also filter deleted_at (defense in depth)
create or replace function lookup_waiter_by_cedula(p_cedula text)
returns table(cedula text, name text, is_active boolean)
language sql
stable
security definer
set search_path to ''public''
as $$
  select cedula, name, is_active
  from public.waiters
  where cedula = p_cedula
    and is_active = true
    and deleted_at is null;
$$","-- 4. current_waiter_id(): also filter deleted_at (defense in depth)
create or replace function current_waiter_id()
returns uuid
language sql
stable
security definer
set search_path to ''public''
as $$
  select id from waiters
  where auth_id = auth.uid()
    and is_active = true
    and deleted_at is null;
$$"}', 'fix_soft_delete_rls');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260818120000', '{"-- Add ''adicional'' status for orders that have additional items added.
-- This status is set when a waiter/admin adds additional items to a served order.
-- It is NOT shown in the dashboard KPI cards or status filters.
-- Flow: adicional → lista (kitchen finishes the additional) → servida

alter table orders
  drop constraint if exists orders_status_check","alter table orders
  add constraint orders_status_check
  check (status in (''nueva'',''en_cocina'',''lista'',''servida'',''adicional''))"}', 'add_adicional_status');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260818130000', '{"-- Add ''additional_added'' to the order_events event_type check constraint.
-- This event type is used when a waiter or admin adds additional items to an order.
-- The original migration was missing this value, causing the event insert to fail silently.

alter table order_events
  drop constraint if exists order_events_event_type_check","alter table order_events
  add constraint order_events_event_type_check
  check (event_type in (''created'',''status_changed'',''printed'',''updated'',''cancelled'',''additional_added''))"}', 'add_additional_added_event_type');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260630120000', '{"-- ============================================================
-- Add order_number column — a human-readable sequential number
-- for each order, shown on printed commands and searchable in
-- the admin dashboard.
--
-- Uses a Postgres SEQUENCE for gap-free sequential numbering.
-- The sequence is owned by the orders table and incremented via
-- a DEFAULT clause, so every INSERT gets the next number
-- automatically without any app-level logic.
-- ============================================================

-- 1. Add the column (nullable first so existing rows don''t fail)
alter table orders add column if not exists order_number int","-- 2. Create a sequence starting at 1
create sequence if not exists orders_order_number_seq as int","-- 3. Backfill existing rows with sequential numbers (oldest first)
with numbered as (
  select id, row_number() over (order by created_at) as rn
  from orders
  where order_number is null
)
update orders o
set order_number = numbered.rn
from numbered
where o.id = numbered.id","-- 4. Set the sequence to the max existing order_number + 1
select setval(''orders_order_number_seq'',
  coalesce((select max(order_number) from orders), 0) + 1,
  false)","-- 5. Make the column NOT NULL with a DEFAULT from the sequence
alter table orders
  alter column order_number set default nextval(''orders_order_number_seq''),
  alter column order_number set not null","-- 6. Create an index for searching by order_number
create index if not exists idx_orders_order_number on orders(order_number)"}', 'add_order_number');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260630130000', '{"-- ============================================================
-- Add CHECK constraints to prevent invalid numeric data.
--
-- The app validates inputs (e.g. delivery_fee > 0, quantity >= 1),
-- but DB-level constraints are the last line of defense against
-- bugs, direct SQL access, or future code that bypasses validation.
-- ============================================================

-- Dishes: price must be non-negative
alter table dishes
  add constraint dishes_price_non_negative check (price >= 0)","-- Orders: total must be non-negative
alter table orders
  add constraint orders_total_non_negative check (total >= 0)","-- Orders: delivery_fee must be non-negative (0 = no fee / non-delivery)
alter table orders
  add constraint orders_delivery_fee_non_negative check (delivery_fee >= 0)","-- Orders: table_number must be positive (1-17 regular, 18 delivery)
alter table orders
  add constraint orders_table_number_positive check (table_number > 0)","-- Order items: price must be non-negative (snapshot of dish price)
alter table order_items
  add constraint order_items_price_non_negative check (price >= 0)","-- Order items: quantity must be at least 1
alter table order_items
  add constraint order_items_quantity_min_one check (quantity >= 1)"}', 'add_check_constraints');


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--



--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 81, true);


--
-- Name: orders_order_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_order_number_seq', 14, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 2464, true);


--
-- PostgreSQL database dump complete
--

\unrestrict 4zyMRggx3lIlQRbHLhMenbzaj69TVJU6yxa91a1kex0m0KjgVjKXMadOkPVtkRu

