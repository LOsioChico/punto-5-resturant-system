--
-- PostgreSQL database dump
--

\restrict cWyHKX2lCyTAZggfQre0WYWnr6txMx6zY2YNbTodVSXgebRYTlBR25PjQvcEhhX

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', '045d810f-e3f9-4836-b880-7488aec90f8a', 'authenticated', 'authenticated', 'deleted+1235340086+1782766139590@punto5.co', '$2a$10$wW5mdKGUFPvpJlm9u2/LO.RrsZXGoZLIsMx0qoF6NzKN5tPSXjwHi', '2026-06-29 20:48:55.843908+00', NULL, '', NULL, '', NULL, '', '', NULL, NULL, '{"role": "waiter", "provider": "email", "providers": ["email"]}', '{"name": "Luis Mesero", "role": "waiter", "cedula": "1235340086", "email_verified": true}', NULL, '2026-06-29 20:48:55.836102+00', '2026-06-29 20:48:59.671991+00', NULL, NULL, '', '', NULL, '', 0, '2126-06-05 20:48:59.67175+00', '', NULL, false, NULL, false);
INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', '6ffe89e6-eeec-474d-b0a1-da76d51355c6', 'authenticated', 'authenticated', '1235340086@punto5.co', '$2a$10$dKwOC7veAHJ937rd.XKdUOsa7o77g/MfolMzSLTBYGI1cIxknA6A2', '2026-06-29 20:50:06.01389+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-06-29 22:43:24.937054+00', '{"role": "waiter", "provider": "email", "providers": ["email"]}', '{"name": "Luis Mesero", "role": "waiter", "cedula": "1235340086", "email_verified": true}', NULL, '2026-06-29 20:50:06.007588+00', '2026-06-30 20:48:05.787221+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);
INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', 'authenticated', 'authenticated', 'osiochico@gmail.com', '$2a$10$bHkI3JKgbBZ4GnJTvnZrmejy6SOIC6bXEvAYd2ku/tInKEfmAkTm6', '2026-06-28 21:59:26.517157+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-06-28 22:08:07.825285+00', '{"role": "admin", "provider": "email", "providers": ["email"]}', '{"full_name": "Luis", "email_verified": true}', NULL, '2026-06-28 21:59:26.500231+00', '2026-06-30 20:51:42.32099+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);
INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', 'authenticated', 'authenticated', 'deleted+1235340086+1782766126806@punto5.co', '$2a$10$LwpYyy3.9CIfjCDAEmcw4uwNbNuITC9qlH8W6WBnPv5zmqv7GU/XO', '2026-06-28 22:10:57.422928+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-06-28 23:13:46.917071+00', '{"role": "waiter", "provider": "email", "providers": ["email"]}', '{"name": "Luis", "role": "waiter", "cedula": "1235340086", "email_verified": true}', NULL, '2026-06-28 22:10:57.402511+00', '2026-06-29 20:48:47.110748+00', NULL, NULL, '', '', NULL, '', 0, '2126-06-05 20:48:47.110498+00', '', NULL, false, NULL, false);


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('f5d56202-ff1c-44f3-b720-5d5d8e727579', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '{"sub": "f5d56202-ff1c-44f3-b720-5d5d8e727579", "email": "osiochico@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-06-28 21:59:26.51219+00', '2026-06-28 21:59:26.512241+00', '2026-06-28 21:59:26.512241+00', 'bdb02c21-c01a-46ef-80c6-9b3d8a5f9227');
INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('d6df41dc-f4f0-49ec-85f7-7c83088266f0', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', '{"sub": "d6df41dc-f4f0-49ec-85f7-7c83088266f0", "email": "deleted+1235340086+1782766126806@punto5.co", "email_verified": false, "phone_verified": false}', 'email', '2026-06-28 22:10:57.41574+00', '2026-06-28 22:10:57.415798+00', '2026-06-28 22:10:57.415798+00', 'dd2ba368-9d8d-428c-bf0c-6e2f17adc6c0');
INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('045d810f-e3f9-4836-b880-7488aec90f8a', '045d810f-e3f9-4836-b880-7488aec90f8a', '{"sub": "045d810f-e3f9-4836-b880-7488aec90f8a", "email": "deleted+1235340086+1782766139590@punto5.co", "email_verified": false, "phone_verified": false}', 'email', '2026-06-29 20:48:55.841342+00', '2026-06-29 20:48:55.841394+00', '2026-06-29 20:48:55.841394+00', 'dc615038-90d3-41ed-a32e-243b6ff00be0');
INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('6ffe89e6-eeec-474d-b0a1-da76d51355c6', '6ffe89e6-eeec-474d-b0a1-da76d51355c6', '{"sub": "6ffe89e6-eeec-474d-b0a1-da76d51355c6", "email": "1235340086@punto5.co", "email_verified": false, "phone_verified": false}', 'email', '2026-06-29 20:50:06.011788+00', '2026-06-29 20:50:06.011838+00', '2026-06-29 20:50:06.011838+00', '25c4e160-f244-4081-b057-76a6b94d1d5c');


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('67ea52dd-4455-43b9-8714-cdbb9a40efbb', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-06-28 22:06:10.874701+00', '2026-06-28 22:06:10.874701+00', NULL, 'aal1', NULL, NULL, 'node', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('df95c8b6-bad5-4ee6-ab2f-ac19a00359d0', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-06-28 22:06:18.590312+00', '2026-06-28 22:06:18.590312+00', NULL, 'aal1', NULL, NULL, 'node', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('fc75e267-925a-478b-9e2a-c2b06c26787e', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-06-28 22:06:33.134096+00', '2026-06-28 22:06:33.134096+00', NULL, 'aal1', NULL, NULL, 'node', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('d50ac3e3-dc9f-4ad8-8bb5-eb43233f3f65', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-06-28 22:08:07.827224+00', '2026-06-28 22:08:07.827224+00', NULL, 'aal1', NULL, NULL, 'node', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('ecc7498d-17fd-44b5-9dd0-aede29c7303e', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', '2026-06-28 23:13:45.957733+00', '2026-06-28 23:13:45.957733+00', NULL, 'aal1', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('dea1340a-869d-4ed6-9507-6e3920ca9abd', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', '2026-06-28 23:13:46.917186+00', '2026-06-29 19:37:42.264413+00', NULL, 'aal1', NULL, '2026-06-29 19:37:42.264326', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);
INSERT INTO auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) VALUES ('546eae29-5701-4cd3-8d35-9eb023c464b0', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', '2026-06-28 22:02:38.510992+00', '2026-06-30 20:51:42.333688+00', NULL, 'aal1', NULL, '2026-06-30 20:51:42.333558', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36', '190.255.85.197', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('546eae29-5701-4cd3-8d35-9eb023c464b0', '2026-06-28 22:02:38.524985+00', '2026-06-28 22:02:38.524985+00', 'password', '1ce942e1-29f9-4c29-a685-908fb072984d');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('67ea52dd-4455-43b9-8714-cdbb9a40efbb', '2026-06-28 22:06:10.910402+00', '2026-06-28 22:06:10.910402+00', 'password', 'b42ec5a4-f6a9-40f3-b5a0-4824f0f3eabc');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('df95c8b6-bad5-4ee6-ab2f-ac19a00359d0', '2026-06-28 22:06:18.593124+00', '2026-06-28 22:06:18.593124+00', 'password', 'fe92fa31-2db5-4c38-929b-bdf3146e5c5a');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('fc75e267-925a-478b-9e2a-c2b06c26787e', '2026-06-28 22:06:33.136817+00', '2026-06-28 22:06:33.136817+00', 'password', '4fdd96af-a8a9-4583-88a5-5df606dcf476');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('d50ac3e3-dc9f-4ad8-8bb5-eb43233f3f65', '2026-06-28 22:08:07.861628+00', '2026-06-28 22:08:07.861628+00', 'password', '4a424cbb-046a-49b8-8a3c-02ce81f9f1ee');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('ecc7498d-17fd-44b5-9dd0-aede29c7303e', '2026-06-28 23:13:46.015725+00', '2026-06-28 23:13:46.015725+00', 'password', 'b414fd1e-9c4f-4749-bbd0-7d2702ebb647');
INSERT INTO auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) VALUES ('dea1340a-869d-4ed6-9507-6e3920ca9abd', '2026-06-28 23:13:46.93036+00', '2026-06-28 23:13:46.93036+00', 'password', 'e94f8aa7-e34f-48d3-a395-698a9f6207dd');


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 3, 'h6y6wrk5xhma', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-06-28 22:06:10.898963+00', '2026-06-28 22:06:10.898963+00', NULL, '67ea52dd-4455-43b9-8714-cdbb9a40efbb');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 4, '5lhbq6yuuho3', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-06-28 22:06:18.591651+00', '2026-06-28 22:06:18.591651+00', NULL, 'df95c8b6-bad5-4ee6-ab2f-ac19a00359d0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 5, '2udgnib6ysxo', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-06-28 22:06:33.135406+00', '2026-06-28 22:06:33.135406+00', NULL, 'fc75e267-925a-478b-9e2a-c2b06c26787e');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 7, 'voaefaouxqoi', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-06-28 22:08:07.85586+00', '2026-06-28 22:08:07.85586+00', NULL, 'd50ac3e3-dc9f-4ad8-8bb5-eb43233f3f65');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 2, 'k5mfs2t5yvex', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-28 22:02:38.523131+00', '2026-06-28 23:00:54.288516+00', NULL, '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 24, 'ltk4z6n3tywd', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', false, '2026-06-28 23:13:45.997716+00', '2026-06-28 23:13:45.997716+00', NULL, 'ecc7498d-17fd-44b5-9dd0-aede29c7303e');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 18, 'jjrrxqbg2bup', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-28 23:00:54.293792+00', '2026-06-28 23:59:14.675933+00', 'k5mfs2t5yvex', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 25, 'hcwpgtldj7ay', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-28 23:13:46.923383+00', '2026-06-29 00:12:11.870666+00', NULL, 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 26, '55yjiljmx63j', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-28 23:59:14.698211+00', '2026-06-29 00:57:45.265054+00', 'jjrrxqbg2bup', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 27, 'ihd7nhoene4p', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 00:12:11.883414+00', '2026-06-29 01:10:16.336033+00', 'hcwpgtldj7ay', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 28, 'augi3g5omzgf', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 00:57:45.28246+00', '2026-06-29 01:55:54.361412+00', '55yjiljmx63j', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 29, 'jymnendjpddf', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 01:10:16.345853+00', '2026-06-29 02:08:25.858339+00', 'ihd7nhoene4p', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 30, '6u7uay6gvb7s', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 01:55:54.37731+00', '2026-06-29 02:54:18.47783+00', 'augi3g5omzgf', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 31, 'oiufn4ta6sgr', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 02:08:25.869446+00', '2026-06-29 03:06:29.828161+00', 'jymnendjpddf', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 32, 'mvsxbamiptpa', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 02:54:18.495011+00', '2026-06-29 03:52:25.770646+00', '6u7uay6gvb7s', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 33, 'vnagmhyii53t', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 03:06:29.8451+00', '2026-06-29 04:04:30.109444+00', 'oiufn4ta6sgr', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 35, 'z2ckt4mtmyrg', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 04:04:30.11871+00', '2026-06-29 05:03:00.245729+00', 'vnagmhyii53t', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 36, 'bpzu4zsoifns', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 05:03:00.268805+00', '2026-06-29 06:08:30.517295+00', 'z2ckt4mtmyrg', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 37, 'zlwfv5w3kzz7', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 06:08:30.525901+00', '2026-06-29 07:20:08.243587+00', 'bpzu4zsoifns', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 38, 'rzcr63b7xsam', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 07:20:08.258026+00', '2026-06-29 08:28:28.826255+00', 'zlwfv5w3kzz7', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 39, 'm55piudi7myq', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 08:28:28.846131+00', '2026-06-29 09:33:12.266484+00', 'rzcr63b7xsam', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 40, 'gjjkymsoiqt4', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 09:33:12.276708+00', '2026-06-29 10:34:18.759851+00', 'm55piudi7myq', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 34, 'eodhdcyf3uch', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 03:52:25.785526+00', '2026-06-29 11:14:12.69155+00', 'mvsxbamiptpa', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 41, 'a7gebsaekrmt', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 10:34:18.775064+00', '2026-06-29 11:32:27.501091+00', 'gjjkymsoiqt4', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 42, 'fedipq6bdk32', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 11:14:12.707497+00', '2026-06-29 12:12:15.840955+00', 'eodhdcyf3uch', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 43, 'cfwntjgi23nv', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 11:32:27.51549+00', '2026-06-29 12:30:52.236498+00', 'a7gebsaekrmt', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 45, 'nhlbk5t5zrf3', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', true, '2026-06-29 12:30:52.244052+00', '2026-06-29 19:37:42.230572+00', 'cfwntjgi23nv', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 44, 'waipxt6o4vil', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 12:12:15.853402+00', '2026-06-29 19:37:42.230819+00', 'fedipq6bdk32', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 46, '2ewnzpgjap6q', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', false, '2026-06-29 19:37:42.249287+00', '2026-06-29 19:37:42.249287+00', 'nhlbk5t5zrf3', 'dea1340a-869d-4ed6-9507-6e3920ca9abd');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 47, 'pi5cp5dztev5', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 19:37:42.246854+00', '2026-06-29 20:46:24.747149+00', 'waipxt6o4vil', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 48, 'g4n4jtnxusoc', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 20:46:24.763528+00', '2026-06-29 21:54:33.290474+00', 'pi5cp5dztev5', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 50, 'zqgx4pit46qq', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 21:54:33.30213+00', '2026-06-29 22:53:03.580004+00', 'g4n4jtnxusoc', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 53, 'w6xypf7xs4xu', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 22:53:03.589117+00', '2026-06-29 23:51:10.569329+00', 'zqgx4pit46qq', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 55, 'epkpx2m3f4pg', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-29 23:51:10.580539+00', '2026-06-30 19:52:03.131864+00', 'w6xypf7xs4xu', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 56, 'kbwdgpakdyhr', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', true, '2026-06-30 19:52:03.142985+00', '2026-06-30 20:51:42.313998+00', 'epkpx2m3f4pg', '546eae29-5701-4cd3-8d35-9eb023c464b0');
INSERT INTO auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) VALUES ('00000000-0000-0000-0000-000000000000', 58, '4usx7623kxh4', 'f5d56202-ff1c-44f3-b720-5d5d8e727579', false, '2026-06-30 20:51:42.318702+00', '2026-06-30 20:51:42.318702+00', 'kbwdgpakdyhr', '546eae29-5701-4cd3-8d35-9eb023c464b0');


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.schema_migrations (version) VALUES ('20171026211738');
INSERT INTO auth.schema_migrations (version) VALUES ('20171026211808');
INSERT INTO auth.schema_migrations (version) VALUES ('20171026211834');
INSERT INTO auth.schema_migrations (version) VALUES ('20180103212743');
INSERT INTO auth.schema_migrations (version) VALUES ('20180108183307');
INSERT INTO auth.schema_migrations (version) VALUES ('20180119214651');
INSERT INTO auth.schema_migrations (version) VALUES ('20180125194653');
INSERT INTO auth.schema_migrations (version) VALUES ('00');
INSERT INTO auth.schema_migrations (version) VALUES ('20210710035447');
INSERT INTO auth.schema_migrations (version) VALUES ('20210722035447');
INSERT INTO auth.schema_migrations (version) VALUES ('20210730183235');
INSERT INTO auth.schema_migrations (version) VALUES ('20210909172000');
INSERT INTO auth.schema_migrations (version) VALUES ('20210927181326');
INSERT INTO auth.schema_migrations (version) VALUES ('20211122151130');
INSERT INTO auth.schema_migrations (version) VALUES ('20211124214934');
INSERT INTO auth.schema_migrations (version) VALUES ('20211202183645');
INSERT INTO auth.schema_migrations (version) VALUES ('20220114185221');
INSERT INTO auth.schema_migrations (version) VALUES ('20220114185340');
INSERT INTO auth.schema_migrations (version) VALUES ('20220224000811');
INSERT INTO auth.schema_migrations (version) VALUES ('20220323170000');
INSERT INTO auth.schema_migrations (version) VALUES ('20220429102000');
INSERT INTO auth.schema_migrations (version) VALUES ('20220531120530');
INSERT INTO auth.schema_migrations (version) VALUES ('20220614074223');
INSERT INTO auth.schema_migrations (version) VALUES ('20220811173540');
INSERT INTO auth.schema_migrations (version) VALUES ('20221003041349');
INSERT INTO auth.schema_migrations (version) VALUES ('20221003041400');
INSERT INTO auth.schema_migrations (version) VALUES ('20221011041400');
INSERT INTO auth.schema_migrations (version) VALUES ('20221020193600');
INSERT INTO auth.schema_migrations (version) VALUES ('20221021073300');
INSERT INTO auth.schema_migrations (version) VALUES ('20221021082433');
INSERT INTO auth.schema_migrations (version) VALUES ('20221027105023');
INSERT INTO auth.schema_migrations (version) VALUES ('20221114143122');
INSERT INTO auth.schema_migrations (version) VALUES ('20221114143410');
INSERT INTO auth.schema_migrations (version) VALUES ('20221125140132');
INSERT INTO auth.schema_migrations (version) VALUES ('20221208132122');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195500');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195800');
INSERT INTO auth.schema_migrations (version) VALUES ('20221215195900');
INSERT INTO auth.schema_migrations (version) VALUES ('20230116124310');
INSERT INTO auth.schema_migrations (version) VALUES ('20230116124412');
INSERT INTO auth.schema_migrations (version) VALUES ('20230131181311');
INSERT INTO auth.schema_migrations (version) VALUES ('20230322519590');
INSERT INTO auth.schema_migrations (version) VALUES ('20230402418590');
INSERT INTO auth.schema_migrations (version) VALUES ('20230411005111');
INSERT INTO auth.schema_migrations (version) VALUES ('20230508135423');
INSERT INTO auth.schema_migrations (version) VALUES ('20230523124323');
INSERT INTO auth.schema_migrations (version) VALUES ('20230818113222');
INSERT INTO auth.schema_migrations (version) VALUES ('20230914180801');
INSERT INTO auth.schema_migrations (version) VALUES ('20231027141322');
INSERT INTO auth.schema_migrations (version) VALUES ('20231114161723');
INSERT INTO auth.schema_migrations (version) VALUES ('20231117164230');
INSERT INTO auth.schema_migrations (version) VALUES ('20240115144230');
INSERT INTO auth.schema_migrations (version) VALUES ('20240214120130');
INSERT INTO auth.schema_migrations (version) VALUES ('20240306115329');
INSERT INTO auth.schema_migrations (version) VALUES ('20240314092811');
INSERT INTO auth.schema_migrations (version) VALUES ('20240427152123');
INSERT INTO auth.schema_migrations (version) VALUES ('20240612123726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240729123726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240802193726');
INSERT INTO auth.schema_migrations (version) VALUES ('20240806073726');
INSERT INTO auth.schema_migrations (version) VALUES ('20241009103726');
INSERT INTO auth.schema_migrations (version) VALUES ('20250717082212');
INSERT INTO auth.schema_migrations (version) VALUES ('20250731150234');
INSERT INTO auth.schema_migrations (version) VALUES ('20250804100000');
INSERT INTO auth.schema_migrations (version) VALUES ('20250901200500');
INSERT INTO auth.schema_migrations (version) VALUES ('20250903112500');
INSERT INTO auth.schema_migrations (version) VALUES ('20250904133000');
INSERT INTO auth.schema_migrations (version) VALUES ('20250925093508');
INSERT INTO auth.schema_migrations (version) VALUES ('20251007112900');
INSERT INTO auth.schema_migrations (version) VALUES ('20251104100000');
INSERT INTO auth.schema_migrations (version) VALUES ('20251111201300');
INSERT INTO auth.schema_migrations (version) VALUES ('20251201000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260115000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260121000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260219120000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260302000000');
INSERT INTO auth.schema_migrations (version) VALUES ('20260625000000');


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--



--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, name, sort_order, description) VALUES ('ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Hamburguesas', 1, 'Todas las hamburguesas incluyen una variedad de ingredientes y salsas específicas');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('8ac03b25-93dc-4b8b-b823-9677d87e3dee', 'Salchipapas', 2, 'Papas, salchicha y salsas de la casa');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Perros', 3, 'Long, ripio, queso y salsas de la casa');
INSERT INTO public.categories (id, name, sort_order, description) VALUES ('ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Toppings', 4, 'Adiciones para tu pedido');


--
-- Data for Name: dishes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('bfd38a1f-ce00-4a3f-80df-d63290e5213c', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Sencilla', 'Carne de res, lechuga, ripio, queso mozzarella, salsas (tomate, mostaza, tártara) y papas a la francesa', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('87dac689-9253-41f4-862d-5487ad816081', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Mexicana', 'Carne de res, jalapeño ají vasco, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 6000, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('47fb02f6-4ebf-45b3-8350-e75d34b2be77', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Pollo', 'Carne de pollo, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 6000, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('1aefa3fc-e803-46d9-a466-368b8b128875', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Doble Carne', 'Doble carne de res, jamón, tocineta, ripio, lechuga, queso mozzarella, salsas (tártara, tomate, mostaza) y papas a la francesa', 12000, 4);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('bf522fa8-1011-48b9-8b0d-e1b3d6a48bc9', 'ff5da365-036e-4aff-94bb-e844c4ee3eef', 'Salchiburguer', 'Carne de res, lechuga, ripio, queso mozzarella, papa a la francesa, queso costeño y salsas (tártara, tomate, mostaza, piña)', 10000, 5);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('42731242-c50c-4349-82dd-0ca842e7d385', '8ac03b25-93dc-4b8b-b823-9677d87e3dee', 'Salchipapa', 'Papa a la francesa, salchicha, queso costeño, lechuga, papa ripio y salsas (tomate, tártara, piña)', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('f5066ca4-2346-4bad-9341-dfcfb5b85012', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Sencillo', 'Long (salchicha), ripio, queso mozzarella y salsas (tártara, tomate, mostaza)', 5000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('7d98d4cd-7f6c-4493-b61e-2a66defde2bf', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Planchiperro', 'Long (salchicha), carne de res, lechuga, ripio, queso costeño, queso mozzarella y salsas (tártara, piña, tomate)', 10000, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('75f774af-944f-40c3-a8cf-96cb9c0d9454', '7d1ba807-22d4-4233-987f-9c45bc1f77af', 'Salchidog', 'Long (salchicha), ripio, lechuga, papas a la francesa, salchicha, queso costeño, queso mozzarella y salsas (tártara, piña, mostaza, tomate)', 10000, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('58ae68f1-834d-4658-b6e0-db6681d6b2d2', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Huevo Frito', 'Huevo frito adicional', 1000, 1);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('e99f0ea1-add0-4cec-b8ba-4b6cacfca078', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Jamón', 'Jamón adicional', 1500, 2);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('cf5b4b1a-1c0b-41dd-92f1-fe2e5982ac6c', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Queso Mozzarella', 'Queso mozzarella adicional', 1500, 3);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('7beb2d57-7138-41d4-b1c7-54b4b0ae89b3', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Tocineta', 'Tocineta adicional', 1500, 4);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('2efda1a1-24e7-483b-b617-015962e65410', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Cebolla Caramelizada', 'Cebolla caramelizada adicional', 1500, 5);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('ae28b246-ca3d-4d29-8a45-5c01f6ee652e', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Carne', 'Carne adicional', 3000, 6);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('fef876a3-7b62-41df-ac8d-2e8893d0e880', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Pollo', 'Pollo adicional', 3000, 7);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('67061a8f-9328-42f1-9a3c-c2ace471d317', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Mexicana', 'Mexicana adicional', 3000, 8);
INSERT INTO public.dishes (id, category_id, name, description, price, sort_order) VALUES ('a8f8d2e6-baec-4f1b-98bd-cbfb24ae8d59', 'ad4a1369-185d-48f2-bb18-e12736be4b1f', 'Porción de Papas', 'Porción de papas a la francesa', 3000, 9);


--
-- Data for Name: waiters; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.waiters (id, auth_id, cedula, name, is_active, pin_changed, created_at, created_by, deleted_at) VALUES ('9dcc055d-d7b4-4a3e-9834-b7b6be0f5545', 'd6df41dc-f4f0-49ec-85f7-7c83088266f0', '1235340086', 'Luis', false, true, '2026-06-28 22:10:57.706548+00', 'osiochico@gmail.com', '2026-06-29 20:48:46.669+00');
INSERT INTO public.waiters (id, auth_id, cedula, name, is_active, pin_changed, created_at, created_by, deleted_at) VALUES ('20253620-6417-49db-b3aa-2c737332554e', '045d810f-e3f9-4836-b880-7488aec90f8a', '1235340086', 'Luis Mesero', false, false, '2026-06-29 20:48:56.157546+00', 'osiochico@gmail.com', '2026-06-29 20:48:59.467+00');
INSERT INTO public.waiters (id, auth_id, cedula, name, is_active, pin_changed, created_at, created_by, deleted_at) VALUES ('69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', '6ffe89e6-eeec-474d-b0a1-da76d51355c6', '1235340086', 'Luis Mesero', true, true, '2026-06-29 20:50:06.119752+00', 'osiochico@gmail.com', NULL);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('00508261-4928-482a-80dc-4a87954649d4', 3, 'Luis Mesero', 'finalizada', 62000, NULL, '2026-06-29 20:53:17.502699+00', 'Luis Mesero', '2026-06-29 20:57:37+00', 'waiter', NULL, 0, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', NULL, 1);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('719feacd-84e5-40d0-bd82-05bd2ba1dd1a', 18, 'Luis Mesero', 'finalizada', 44000, NULL, '2026-06-29 20:58:41.554177+00', 'Luis', '2026-06-29 20:59:18+00', 'admin', 'Yeison', 0, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', '2026-06-29 20:59:34+00', 2);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('0c7930b2-9b43-405c-b2b4-29ca0970ee87', 18, 'Luis Mesero', 'finalizada', 33000, NULL, '2026-06-29 22:03:28.288335+00', 'Luis', '2026-06-29 22:14:32+00', 'admin', 'Jose', 0, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', NULL, 3);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('a539a475-9917-490e-a7b1-69cc4594700c', 13, 'Luis Mesero', 'finalizada', 37000, NULL, '2026-06-29 22:15:45.291129+00', 'Luis Mesero', '2026-06-29 22:17:47+00', 'waiter', NULL, 0, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', NULL, 4);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('72935cd8-7e91-4c23-8b66-cc65a78ff5be', 18, 'Luis Mesero', 'nueva', 20000, NULL, '2026-06-29 23:31:33.285693+00', NULL, NULL, NULL, 'Amador', 0, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', NULL, 5);
INSERT INTO public.orders (id, table_number, waiter_name, status, total, notes, created_at, updated_by, updated_at, updated_by_type, delivery_name, delivery_fee, waiter_id, deleted_at, order_number) VALUES ('0ca8e73c-9a23-497f-8382-e7c3b1ff81d8', 18, 'Luis Mesero', 'nueva', 38000, NULL, '2026-06-30 00:09:22.858178+00', 'Luis', '2026-06-30 00:16:27+00', 'admin', 'Alex', 4000, '69ec61c9-1edc-4e7f-a042-0b6f8cc52a77', NULL, 6);


--
-- Data for Name: order_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('06509066-2765-4b2a-a024-c1923410f1c3', '00508261-4928-482a-80dc-4a87954649d4', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 26000, "item_count": 4, "table_number": 3}', '2026-06-29 20:53:18.152625+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('f2af36f1-1187-48df-88c6-17529ff867e0', '00508261-4928-482a-80dc-4a87954649d4', 'status_changed', 'admin', 'Luis', 'nueva', 'en_cocina', '{}', '2026-06-29 20:54:01.954421+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('4991cd61-878f-4546-b262-bea8ba02b286', '00508261-4928-482a-80dc-4a87954649d4', 'status_changed', 'admin', 'Luis', 'en_cocina', 'servida', '{}', '2026-06-29 20:54:07.371901+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('ab0f67aa-6fd2-42ed-9c19-7f89b6c383e6', '00508261-4928-482a-80dc-4a87954649d4', 'additional_added', 'waiter', 'Luis Mesero', 'servida', 'adicional', '{"new_total": 44000, "item_count": 3, "added_items": [{"qty": 3, "name": "Salchipapa", "notes": ["Para llevar", "Para llevar", "Para llevar"]}], "additional_total": 18000, "additional_number": 1, "additional_desechables": 3000}', '2026-06-29 20:55:23.519007+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('6c0eef71-2942-404e-ba48-d65c30bd1db9', '00508261-4928-482a-80dc-4a87954649d4', 'additional_added', 'waiter', 'Luis Mesero', 'finalizada', 'adicional', '{"new_total": 62000, "item_count": 3, "added_items": [{"qty": 3, "name": "Sencillo", "notes": ["Para llevar", "Para llevar", "Para llevar"]}], "additional_total": 18000, "additional_number": 2, "additional_desechables": 3000}', '2026-06-29 20:57:11.401897+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('83229bd1-d1ec-4ea7-932e-f3dbf6939db0', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 44000, "item_count": 4, "table_number": 18}', '2026-06-29 20:58:42.074015+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('0bb56195-0c54-421c-8ae8-90589cf1d593', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', 'status_changed', 'admin', 'Luis', 'nueva', 'en_cocina', '{}', '2026-06-29 20:58:53.729507+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('9ca1962b-c983-4ef6-ad10-e35f4f519d74', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', 'status_changed', 'admin', 'Luis', 'servida', 'finalizada', '{}', '2026-06-29 20:59:18.98244+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('3564847f-0549-405e-8d15-d7b3af504329', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', 'cancelled', 'admin', 'Luis', NULL, NULL, '{"deleted_at": "2026-06-29T15:59:34-05:00"}', '2026-06-29 20:59:34.468212+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('0462a3aa-dde9-49b7-bc6a-0891debef118', '0c7930b2-9b43-405c-b2b4-29ca0970ee87', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 33000, "item_count": 3, "table_number": 18}', '2026-06-29 22:03:29.190383+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('ce906a89-019b-4bad-a86d-266858638533', '0c7930b2-9b43-405c-b2b4-29ca0970ee87', 'status_changed', 'admin', 'Luis', 'nueva', 'en_cocina', '{}', '2026-06-29 22:03:38.171822+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('19b4b636-b996-41bb-9aa8-ffd0e2281cd9', '0c7930b2-9b43-405c-b2b4-29ca0970ee87', 'status_changed', 'admin', 'Luis', 'en_cocina', 'servida', '{}', '2026-06-29 22:03:42.581765+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('20446a32-0f36-4c26-ae34-b64d51b6d5ed', '0c7930b2-9b43-405c-b2b4-29ca0970ee87', 'status_changed', 'admin', 'Luis', 'servida', 'finalizada', '{}', '2026-06-29 22:14:32.966488+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('99b9cda4-d3f3-49d4-89de-afc86790b764', 'a539a475-9917-490e-a7b1-69cc4594700c', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 16000, "item_count": 3, "table_number": 13}', '2026-06-29 22:15:45.886657+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('54fe8dfe-0bd6-49de-bebc-86879e31280f', 'a539a475-9917-490e-a7b1-69cc4594700c', 'status_changed', 'admin', 'Luis', 'nueva', 'en_cocina', '{}', '2026-06-29 22:16:04.294821+00', 'f5d56202-ff1c-44f3-b720-5d5d8e727579');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('6702bc51-6def-4d96-80ce-2855c420d6aa', 'a539a475-9917-490e-a7b1-69cc4594700c', 'status_changed', 'waiter', 'Luis Mesero', 'en_cocina', 'servida', '{}', '2026-06-29 22:16:13.876579+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('9857acc0-3114-4697-9000-17f6e8fb6873', 'a539a475-9917-490e-a7b1-69cc4594700c', 'additional_added', 'waiter', 'Luis Mesero', 'servida', 'adicional', '{"new_total": 37000, "item_count": 2, "added_items": [{"qty": 2, "name": "Planchiperro", "notes": ["Sin tártara", "Para llevar"]}], "additional_total": 21000, "additional_number": 1, "additional_desechables": 1000}', '2026-06-29 22:16:55.499664+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('368338e1-7ed5-414c-a184-d3a7632c30cc', 'a539a475-9917-490e-a7b1-69cc4594700c', 'status_changed', 'waiter', 'Luis Mesero', 'adicional', 'finalizada', '{}', '2026-06-29 22:17:48.046664+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('c8993729-ad84-4319-a922-e548649812a2', '72935cd8-7e91-4c23-8b66-cc65a78ff5be', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 20000, "item_count": 2, "table_number": 18}', '2026-06-29 23:31:33.750901+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');
INSERT INTO public.order_events (id, order_id, event_type, actor_type, actor_name, from_status, to_status, metadata, created_at, actor_id) VALUES ('5aa951b2-fa41-4bd3-8047-2c2ddc0ab95a', '0ca8e73c-9a23-497f-8382-e7c3b1ff81d8', 'created', 'waiter', 'Luis Mesero', NULL, 'nueva', '{"total": 39000, "item_count": 4, "table_number": 18}', '2026-06-30 00:09:23.390564+00', '6ffe89e6-eeec-474d-b0a1-da76d51355c6');


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('4143f54e-0cbd-4ba9-8f85-de396baece65', '00508261-4928-482a-80dc-4a87954649d4', 'bfd38a1f-ce00-4a3f-80df-d63290e5213c', 'Sencilla', 5000, 3, '["Sin salsas", "Sin tomate, Sin lechuga", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('6763d341-5195-440f-be0b-1b743d31c58e', '00508261-4928-482a-80dc-4a87954649d4', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 1, NULL, NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('b8963cd6-cee4-4613-bc89-3441ac00eccf', '00508261-4928-482a-80dc-4a87954649d4', '42731242-c50c-4349-82dd-0ca842e7d385', 'Salchipapa', 5000, 3, '["Para llevar", "Para llevar", "Para llevar"]', NULL, true, 1);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('b30dc2d9-0ad9-47f2-84f8-c06222c0b852', '00508261-4928-482a-80dc-4a87954649d4', 'f5066ca4-2346-4bad-9341-dfcfb5b85012', 'Sencillo', 5000, 3, '["Para llevar", "Para llevar", "Para llevar"]', NULL, true, 2);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('2e8a6a41-1aa9-4c80-9cb0-89c7e4946e5e', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 3, '["Para llevar, Sin tártara", "Para llevar, Sin lechuga, Sin piña", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('f4105c98-26de-49c7-b0f1-a2670617abc6', '719feacd-84e5-40d0-bd82-05bd2ba1dd1a', '75f774af-944f-40c3-a8cf-96cb9c0d9454', 'Salchidog', 10000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('faf5e402-93c0-431b-8558-a8712f73f81d', '0c7930b2-9b43-405c-b2b4-29ca0970ee87', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 3, '["Para llevar", "Para llevar", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('f1b8e18c-c797-404d-ac07-57d7ba1245f6', 'a539a475-9917-490e-a7b1-69cc4594700c', 'bfd38a1f-ce00-4a3f-80df-d63290e5213c', 'Sencilla', 5000, 3, '["Sin tomate", "Sin lechuga, Sin tártara", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('f0089d5f-ab46-4c0b-aa81-13a1e62fa22d', 'a539a475-9917-490e-a7b1-69cc4594700c', '7d98d4cd-7f6c-4493-b61e-2a66defde2bf', 'Planchiperro', 10000, 2, '["Sin tártara", "Para llevar"]', NULL, true, 1);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('84a44881-4b04-4582-89e5-d676f6626e00', '72935cd8-7e91-4c23-8b66-cc65a78ff5be', '87dac689-9253-41f4-862d-5487ad816081', 'Mexicana', 6000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('b84b1508-437e-429a-aaeb-d796878986ab', '72935cd8-7e91-4c23-8b66-cc65a78ff5be', '1aefa3fc-e803-46d9-a466-368b8b128875', 'Doble Carne', 12000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('30ac7e63-5e7b-4fe5-9bfa-2dcf06fc81b3', '0ca8e73c-9a23-497f-8382-e7c3b1ff81d8', '87dac689-9253-41f4-862d-5487ad816081', 'Mexicana', 6000, 2, '["Para llevar", "Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('75949fb1-fef5-4bfd-8828-733675e89c73', '0ca8e73c-9a23-497f-8382-e7c3b1ff81d8', '47fb02f6-4ebf-45b3-8350-e75d34b2be77', 'Pollo', 6000, 1, '["Para llevar"]', NULL, false, NULL);
INSERT INTO public.order_items (id, order_id, dish_id, dish_name, price, quantity, notes, category_name, is_additional, additional_number) VALUES ('55ff1216-c7d3-4775-8a55-0b711ed3535a', '0ca8e73c-9a23-497f-8382-e7c3b1ff81d8', '1aefa3fc-e803-46d9-a466-368b8b128875', 'Doble Carne', 12000, 1, '["Para llevar"]', NULL, false, NULL);


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: messages_2026_06_27; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_06_28; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_06_29; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_06_30; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_07_01; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_07_02; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: messages_2026_07_03; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116024918, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116045059, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116050929, '2026-06-26 21:56:06');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116051442, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116212300, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116213355, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116213934, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211116214523, '2026-06-26 21:56:07');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211122062447, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211124070109, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211202204204, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211202204605, '2026-06-26 21:56:08');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211210212804, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20211228014915, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220107221237, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220228202821, '2026-06-26 21:56:09');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220312004840, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220603231003, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220603232444, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220615214548, '2026-06-26 21:56:10');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220712093339, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220908172859, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20220916233421, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230119133233, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230128025114, '2026-06-26 21:56:11');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230128025212, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230227211149, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230228184745, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230308225145, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20230328144023, '2026-06-26 21:56:12');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231018144023, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144023, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144024, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20231204144025, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240108234812, '2026-06-26 21:56:13');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240109165339, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240227174441, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240311171622, '2026-06-26 21:56:14');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240321100241, '2026-06-26 21:56:15');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240401105812, '2026-06-26 21:56:15');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240418121054, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240523004032, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240618124746, '2026-06-26 21:56:16');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240801235015, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240805133720, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240827160934, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240919163303, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20240919163305, '2026-06-26 21:56:17');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241019105805, '2026-06-26 21:56:18');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241030150047, '2026-06-26 21:56:18');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241108114728, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241121104152, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241130184212, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241220035512, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241220123912, '2026-06-26 21:56:19');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20241224161212, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250107150512, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250110162412, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250123174212, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250128220012, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250506224012, '2026-06-26 21:56:20');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250523164012, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250714121412, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20250905041441, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251103001201, '2026-06-26 21:56:21');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251120212548, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20251120215549, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260218120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260326120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260514120000, '2026-06-26 21:56:22');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260527120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260528120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260603120000, '2026-06-26 21:56:23');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260605120000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260606110000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260616120000, '2026-06-26 21:56:24');
INSERT INTO realtime.schema_migrations (version, inserted_at) VALUES (20260624120000, '2026-06-26 21:56:25');


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--



--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (0, 'create-migrations-table', 'e18db593bcde2aca2a408c4d1100f6abba2195df', '2026-06-26 19:34:26.745323');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (1, 'initialmigration', '6ab16121fbaa08bbd11b712d05f358f9b555d777', '2026-06-26 19:34:26.781197');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (2, 'storage-schema', 'f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd', '2026-06-26 19:34:26.786123');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (3, 'pathtoken-column', '2cb1b0004b817b29d5b0a971af16bafeede4b70d', '2026-06-26 19:34:26.814651');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (4, 'add-migrations-rls', '427c5b63fe1c5937495d9c635c263ee7a5905058', '2026-06-26 19:34:26.831082');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (5, 'add-size-functions', '79e081a1455b63666c1294a440f8ad4b1e6a7f84', '2026-06-26 19:34:26.835546');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (6, 'change-column-name-in-get-size', 'ded78e2f1b5d7e616117897e6443a925965b30d2', '2026-06-26 19:34:26.840646');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (7, 'add-rls-to-buckets', 'e7e7f86adbc51049f341dfe8d30256c1abca17aa', '2026-06-26 19:34:26.845542');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (8, 'add-public-to-buckets', 'fd670db39ed65f9d08b01db09d6202503ca2bab3', '2026-06-26 19:34:26.849868');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (9, 'fix-search-function', 'af597a1b590c70519b464a4ab3be54490712796b', '2026-06-26 19:34:26.854819');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (10, 'search-files-search-function', 'b595f05e92f7e91211af1bbfe9c6a13bb3391e16', '2026-06-26 19:34:26.859362');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (11, 'add-trigger-to-auto-update-updated_at-column', '7425bdb14366d1739fa8a18c83100636d74dcaa2', '2026-06-26 19:34:26.865893');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (12, 'add-automatic-avif-detection-flag', '8e92e1266eb29518b6a4c5313ab8f29dd0d08df9', '2026-06-26 19:34:26.871146');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (13, 'add-bucket-custom-limits', 'cce962054138135cd9a8c4bcd531598684b25e7d', '2026-06-26 19:34:26.875645');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (14, 'use-bytes-for-max-size', '941c41b346f9802b411f06f30e972ad4744dad27', '2026-06-26 19:34:26.880341');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (15, 'add-can-insert-object-function', '934146bc38ead475f4ef4b555c524ee5d66799e5', '2026-06-26 19:34:26.908682');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (16, 'add-version', '76debf38d3fd07dcfc747ca49096457d95b1221b', '2026-06-26 19:34:26.913274');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (17, 'drop-owner-foreign-key', 'f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101', '2026-06-26 19:34:26.917804');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (18, 'add_owner_id_column_deprecate_owner', 'e7a511b379110b08e2f214be852c35414749fe66', '2026-06-26 19:34:26.922334');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (19, 'alter-default-value-objects-id', '02e5e22a78626187e00d173dc45f58fa66a4f043', '2026-06-26 19:34:26.929729');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (20, 'list-objects-with-delimiter', 'cd694ae708e51ba82bf012bba00caf4f3b6393b7', '2026-06-26 19:34:26.934267');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (21, 's3-multipart-uploads', '8c804d4a566c40cd1e4cc5b3725a664a9303657f', '2026-06-26 19:34:26.940364');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (22, 's3-multipart-uploads-big-ints', '9737dc258d2397953c9953d9b86920b8be0cdb73', '2026-06-26 19:34:26.95579');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (23, 'optimize-search-function', '9d7e604cddc4b56a5422dc68c9313f4a1b6f132c', '2026-06-26 19:34:26.965583');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (24, 'operation-function', '8312e37c2bf9e76bbe841aa5fda889206d2bf8aa', '2026-06-26 19:34:26.971739');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (25, 'custom-metadata', 'd974c6057c3db1c1f847afa0e291e6165693b990', '2026-06-26 19:34:26.976214');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (26, 'objects-prefixes', '215cabcb7f78121892a5a2037a09fedf9a1ae322', '2026-06-26 19:34:26.980919');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (27, 'search-v2', '859ba38092ac96eb3964d83bf53ccc0b141663a6', '2026-06-26 19:34:26.985132');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (28, 'object-bucket-name-sorting', 'c73a2b5b5d4041e39705814fd3a1b95502d38ce4', '2026-06-26 19:34:26.989511');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (29, 'create-prefixes', 'ad2c1207f76703d11a9f9007f821620017a66c21', '2026-06-26 19:34:26.993794');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (30, 'update-object-levels', '2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6', '2026-06-26 19:34:26.997923');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (31, 'objects-level-index', 'b40367c14c3440ec75f19bbce2d71e914ddd3da0', '2026-06-26 19:34:27.001904');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (32, 'backward-compatible-index-on-objects', 'e0c37182b0f7aee3efd823298fb3c76f1042c0f7', '2026-06-26 19:34:27.006984');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (33, 'backward-compatible-index-on-prefixes', 'b480e99ed951e0900f033ec4eb34b5bdcb4e3d49', '2026-06-26 19:34:27.01135');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (34, 'optimize-search-function-v1', 'ca80a3dc7bfef894df17108785ce29a7fc8ee456', '2026-06-26 19:34:27.015382');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (35, 'add-insert-trigger-prefixes', '458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc', '2026-06-26 19:34:27.019583');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (36, 'optimise-existing-functions', '6ae5fca6af5c55abe95369cd4f93985d1814ca8f', '2026-06-26 19:34:27.023708');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (37, 'add-bucket-name-length-trigger', '3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1', '2026-06-26 19:34:27.027789');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (38, 'iceberg-catalog-flag-on-buckets', '02716b81ceec9705aed84aa1501657095b32e5c5', '2026-06-26 19:34:27.033042');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (39, 'add-search-v2-sort-support', '6706c5f2928846abee18461279799ad12b279b78', '2026-06-26 19:34:27.043697');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (40, 'fix-prefix-race-conditions-optimized', '7ad69982ae2d372b21f48fc4829ae9752c518f6b', '2026-06-26 19:34:27.047592');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (41, 'add-object-level-update-trigger', '07fcf1a22165849b7a029deed059ffcde08d1ae0', '2026-06-26 19:34:27.051556');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (42, 'rollback-prefix-triggers', '771479077764adc09e2ea2043eb627503c034cd4', '2026-06-26 19:34:27.05559');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (43, 'fix-object-level', '84b35d6caca9d937478ad8a797491f38b8c2979f', '2026-06-26 19:34:27.059651');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (44, 'vector-bucket-type', '99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3', '2026-06-26 19:34:27.06456');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (45, 'vector-buckets', '049e27196d77a7cb76497a85afae669d8b230953', '2026-06-26 19:34:27.069367');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (46, 'buckets-objects-grants', 'fedeb96d60fefd8e02ab3ded9fbde05632f84aed', '2026-06-26 19:34:27.080682');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (47, 'iceberg-table-metadata', '649df56855c24d8b36dd4cc1aeb8251aa9ad42c2', '2026-06-26 19:34:27.085353');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (48, 'iceberg-catalog-ids', 'e0e8b460c609b9999ccd0df9ad14294613eed939', '2026-06-26 19:34:27.089463');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (49, 'buckets-objects-grants-postgres', '072b1195d0d5a2f888af6b2302a1938dd94b8b3d', '2026-06-26 19:34:27.105436');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (50, 'search-v2-optimised', '6323ac4f850aa14e7387eb32102869578b5bd478', '2026-06-26 19:34:27.110761');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (51, 'index-backward-compatible-search', '2ee395d433f76e38bcd3856debaf6e0e5b674011', '2026-06-26 19:34:27.128929');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (52, 'drop-not-used-indexes-and-functions', '5cc44c8696749ac11dd0dc37f2a3802075f3a171', '2026-06-26 19:34:27.130805');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (53, 'drop-index-lower-name', 'd0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854', '2026-06-26 19:34:27.139991');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (54, 'drop-index-object-level', '6289e048b1472da17c31a7eba1ded625a6457e67', '2026-06-26 19:34:27.142898');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (55, 'prevent-direct-deletes', '262a4798d5e0f2e7c8970232e03ce8be695d5819', '2026-06-26 19:34:27.144782');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (56, 'fix-optimized-search-function', 'b823ed1e418101032fa01374edc9a436e54e3ed4', '2026-06-26 19:34:27.150183');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (57, 's3-multipart-uploads-metadata', 'f127886e00d1b374fadbc7c6b31e09336aad5287', '2026-06-26 19:34:27.155535');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (58, 'operation-ergonomics', '00ca5d483b3fe0d522133d9002ccc5df98365120', '2026-06-26 19:34:27.160008');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (59, 'drop-unused-functions', '38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4', '2026-06-26 19:34:27.164915');
INSERT INTO storage.migrations (id, name, hash, executed_at) VALUES (60, 'optimize-existing-functions-again', 'db35e1c91a9201e59f4fef8d972c2f277d68b157', '2026-06-26 19:34:27.169547');


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--



--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: -
--

INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627170000', '{"alter table order_items alter column notes type jsonb","alter table order_items add constraint notes_is_text_array check (notes is null or jsonb_typeof(notes) = ''array'')"}', 'notes_to_jsonb');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627160152', '{"-- ============================================================
-- Punto 5 — POC schema
-- Run this in the Supabase SQL editor.
-- Object names and comments are in English.
-- Seed data (category/dish names, descriptions) is in Spanish
-- because that is the user-facing language of the app.
-- ============================================================

-- Categories (e.g. Hamburguesas, Salchipapas y Perros, Adicionales)
create table if not exists categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text not null default '''',  -- short subtitle shown in POS (e.g. \"Hamburguesas artesanales\")
  sort_order  int  not null default 0
)","-- Dishes within a category
create table if not exists dishes (
  id           uuid primary key default gen_random_uuid(),
  category_id  uuid not null references categories(id) on delete cascade,
  name         text not null,
  description  text not null default '''',
  price        int  not null default 0,   -- price in Colombian pesos
  sort_order   int  not null default 0
)","create index if not exists idx_dishes_category on dishes(category_id)","-- Orders placed by waiters from the POS
create table if not exists orders (
  id              uuid primary key default gen_random_uuid(),
  table_number    int  not null,              -- table number
  waiter_name     text not null,              -- waiter name (no auth in POC)
  status          text not null default ''nueva''
    check (status in (''nueva'',''en_cocina'',''lista'',''servida'')),
  total           int  not null default 0,    -- total in pesos
  notes           text,
  created_at      timestamptz not null default now(),
  -- Audit tracking: who last touched this order
  updated_by      text,                        -- name of the last actor
  updated_at      timestamptz,                 -- when it was last updated
  updated_by_type text check (updated_by_type in (''waiter'',''admin'',''system''))
)","create index if not exists idx_orders_created on orders(created_at desc)","create index if not exists idx_orders_status  on orders(status)","-- Line items per order
create table if not exists order_items (
  id         uuid primary key default gen_random_uuid(),
  order_id   uuid not null references orders(id) on delete cascade,
  dish_id    uuid references dishes(id),
  dish_name     text not null,               -- snapshot of dish name at order time
  price         int  not null,               -- snapshot of price at order time
  quantity      int  not null default 1,
  notes         text                          -- per-item instructions (migrated to jsonb in later migration)
)","create index if not exists idx_order_items_order on order_items(order_id)","-- ============================================================
-- Audit trail — every action on an order is logged here.
-- This gives us full traceability: who did what, when, and
-- what changed (from/to for status transitions, metadata for
-- prints and other events).
-- ============================================================
create table if not exists order_events (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references orders(id) on delete cascade,
  event_type  text not null check (event_type in
    (''created'',''status_changed'',''printed'',''updated'',''cancelled'')),
  actor_type  text not null check (actor_type in (''waiter'',''admin'',''system'')),
  actor_name  text not null,               -- waiter name or ''admin''
  from_status text,                         -- previous status (for status_changed)
  to_status   text,                         -- new status (for status_changed)
  metadata    jsonb not null default ''{}'',  -- flexible: print count, changed fields, etc.
  created_at  timestamptz not null default now()
)","create index if not exists idx_order_events_order on order_events(order_id, created_at desc)","-- ============================================================
-- Push subscriptions — one waiter can have multiple devices
-- ============================================================
create table if not exists push_subscriptions (
  id            uuid primary key default gen_random_uuid(),
  waiter_name   text not null,                          -- waiter name (links to orders.waiter_name)
  endpoint      text not null,                          -- push service endpoint URL (unique per device/browser)
  p256dh        text not null,                          -- ECDH public key from browser
  auth          text not null,                          -- auth secret from browser
  created_at    timestamptz not null default now()
)","create index if not exists idx_push_subs_waiter on push_subscriptions(waiter_name)","create unique index if not exists idx_push_subs_endpoint on push_subscriptions(endpoint)","-- ============================================================
-- RLS — POC: allow all operations with the anon key.
-- Tighten before production.
--
-- Production RLS should enforce:
--   - Waiters can only UPDATE orders where waiter_name = auth.uid()
--     (i.e. they can only modify orders they created).
--   - Admins can UPDATE any order.
--   - Waiters can only INSERT order_events for their own orders.
-- The app-level check (isOrderOwner in lib/utils.ts) covers this
-- for the POC, but RLS is the real enforcement layer.
-- ============================================================

-- GRANTs — Supabase''s new default (2026+) does NOT auto-expose tables
-- to the anon/authenticated roles. RLS policies alone are not enough;
-- the underlying table privileges must be granted explicitly.
grant select on categories    to anon, authenticated","grant select on dishes        to anon, authenticated","grant select on orders        to anon, authenticated","grant insert on orders        to anon, authenticated","grant update on orders        to anon, authenticated","grant select on order_items   to anon, authenticated","grant insert on order_items   to anon, authenticated","grant update on order_items   to anon, authenticated","grant delete on order_items   to anon, authenticated","grant select on order_events  to anon, authenticated","grant insert on order_events  to anon, authenticated","grant insert on push_subscriptions to anon, authenticated","grant delete on push_subscriptions to anon, authenticated","grant select on push_subscriptions to anon, authenticated","alter table categories    enable row level security","alter table dishes        enable row level security","alter table orders        enable row level security","alter table order_items   enable row level security","alter table order_events  enable row level security","alter table push_subscriptions enable row level security","create policy \"poc_read_categories\"  on categories  for select using (true)","create policy \"poc_read_dishes\"      on dishes      for select using (true)","create policy \"poc_read_orders\"      on orders      for select using (true)","create policy \"poc_insert_orders\"    on orders      for insert with check (true)","create policy \"poc_update_orders\"    on orders      for update using (true)","create policy \"poc_delete_orders\"    on orders      for delete using (true)","create policy \"poc_read_order_items\"   on order_items  for select using (true)","create policy \"poc_insert_order_items\" on order_items  for insert with check (true)","create policy \"poc_update_order_items\" on order_items  for update using (true)","create policy \"poc_delete_order_items\" on order_items  for delete using (true)","create policy \"poc_read_order_events\"  on order_events for select using (true)","create policy \"poc_insert_order_events\" on order_events for insert with check (true)","create policy \"poc_insert_push_subs\" on push_subscriptions for insert with check (true)","create policy \"poc_delete_push_subs\" on push_subscriptions for delete using (true)","create policy \"poc_read_push_subs\"   on push_subscriptions for select using (true)","-- ============================================================
-- Realtime — enable publication for the tables we subscribe to
-- ============================================================
alter publication supabase_realtime add table orders","alter publication supabase_realtime add table order_items","alter publication supabase_realtime add table order_events","-- ============================================================
-- Seed data — real menu
-- ============================================================
insert into categories (name, description, sort_order) values
  (''Hamburguesas'', ''Todas las hamburguesas incluyen una variedad de ingredientes y salsas específicas'', 1),
  (''Salchipapas'', ''Papas, salchicha y salsas de la casa'', 2),
  (''Perros'', ''Long, ripio, queso y salsas de la casa'', 3),
  (''Toppings'', ''Adiciones para tu pedido'', 4)
on conflict do nothing","-- Hamburguesas
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Sencilla'',      ''Carne de res, lechuga, ripio, queso mozzarella, salsas (tomate, mostaza, tártara) y papas a la francesa'', 5000, 1),
  (''Mexicana'',      ''Carne de res, jalapeño ají vasco, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 6000, 2),
  (''Pollo'',         ''Carne de pollo, lechuga, ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 6000, 3),
  (''Doble Carne'',   ''Doble carne de res, jamón, tocineta, ripio, lechuga, queso mozzarella, salsas (tártara, tomate, mostaza) y papas a la francesa'', 12000, 4),
  (''Salchiburguer'', ''Carne de res, lechuga, ripio, queso mozzarella, papa a la francesa, queso costeño y salsas (tártara, tomate, mostaza, piña)'', 10000, 5)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Hamburguesas''
on conflict do nothing","-- Salchipapas
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Salchipapa'', ''Papa a la francesa, salchicha, queso costeño, lechuga, papa ripio y salsas (tomate, tártara, piña)'', 5000, 1)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Salchipapas''
on conflict do nothing","-- Perros
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Sencillo'',     ''Long (salchicha), ripio, queso mozzarella y salsas (tártara, tomate, mostaza)'', 5000, 1),
  (''Planchiperro'', ''Long (salchicha), carne de res, lechuga, ripio, queso costeño, queso mozzarella y salsas (tártara, piña, tomate)'', 10000, 2),
  (''Salchidog'',    ''Long (salchicha), ripio, lechuga, papas a la francesa, salchicha, queso costeño, queso mozzarella y salsas (tártara, piña, mostaza, tomate)'', 10000, 3)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Perros''
on conflict do nothing","-- Toppings (Adiciones)
insert into dishes (category_id, name, description, price, sort_order)
select c.id, d.name, d.description, d.price, d.sort_order
from (values
  (''Huevo Frito'',           ''Huevo frito adicional'', 1000, 1),
  (''Jamón'',                 ''Jamón adicional'', 1500, 2),
  (''Queso Mozzarella'',      ''Queso mozzarella adicional'', 1500, 3),
  (''Tocineta'',              ''Tocineta adicional'', 1500, 4),
  (''Cebolla Caramelizada'',  ''Cebolla caramelizada adicional'', 1500, 5),
  (''Carne'',                 ''Carne adicional'', 3000, 6),
  (''Pollo'',                 ''Pollo adicional'', 3000, 7),
  (''Mexicana'',              ''Mexicana adicional'', 3000, 8),
  (''Porción de Papas'',      ''Porción de papas a la francesa'', 3000, 9)
) as d(name, description, price, sort_order)
cross join categories c
where c.name = ''Toppings''
on conflict do nothing"}', 'initial_schema');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627180000', '{"-- Add delivery_name column for delivery/to-go orders (table 18)
-- When an order is for \"Domicilio\", this stores the customer name or description
-- so the kitchen knows who it''s for.
ALTER TABLE orders ADD COLUMN delivery_name text","-- Delivery orders (table 18) should have a delivery_name
-- We enforce this at the app level, not via DB constraint, to avoid
-- blocking existing orders."}', 'add_delivery_name');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260627190000', '{"-- Add delivery_fee column for admin-set delivery charge per order
-- This is separate from the desechables ($1000/dish) which is automatic
ALTER TABLE orders ADD COLUMN delivery_fee int not null default 0"}', 'add_delivery_fee');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260628060000', '{"-- ============================================================
-- Authentication: waiters table + waiter_id/actor_id columns
--
-- This migration adds:
--   1. `waiters` table — links Supabase Auth accounts to waiter profiles
--   2. `orders.waiter_id` — FK to waiters.id (replaces name-only identification)
--   3. `order_events.actor_id` — FK to auth.users for real audit trail
--   4. Tightened RLS policies (replacing the POC \"allow all\" policies)
--
-- Auth accounts are created via the admin UI (Supabase client),
-- not via this migration. The admin account is created manually
-- via the Supabase dashboard or a setup script.
-- ============================================================

-- ============================================================
-- Waiters table
-- ============================================================
create table if not exists waiters (
  id           uuid primary key default gen_random_uuid(),
  auth_id      uuid not null references auth.users(id) on delete cascade,
  cedula       text not null unique,              -- Colombian national ID
  name         text not null,                      -- display name
  is_active    boolean not null default true,      -- admin can deactivate
  pin_changed  boolean not null default false,     -- false = must change PIN on first login
  created_at   timestamptz not null default now(),
  created_by   text                                -- admin email who created this waiter
)","create index if not exists idx_waiters_auth_id on waiters(auth_id)","create index if not exists idx_waiters_cedula on waiters(cedula)","create index if not exists idx_waiters_active on waiters(is_active) where is_active = true","-- ============================================================
-- Add waiter_id to orders (NOT NULL — every order must have a waiter)
-- Existing test orders are deleted first since they have no waiter_id.
-- ============================================================
alter table orders add column if not exists waiter_id uuid references waiters(id) on delete restrict","-- Delete existing orders that have no waiter_id (test data from POC)
delete from order_items where order_id in (select id from orders where waiter_id is null)","delete from order_events where order_id in (select id from orders where waiter_id is null)","delete from orders where waiter_id is null","-- Now enforce NOT NULL
alter table orders alter column waiter_id set not null","create index if not exists idx_orders_waiter_id on orders(waiter_id)","-- ============================================================
-- Add actor_id to order_events (nullable — system events may not have an actor)
-- ============================================================
alter table order_events add column if not exists actor_id uuid references auth.users(id) on delete set null","create index if not exists idx_order_events_actor_id on order_events(actor_id) where actor_id is not null","-- ============================================================
-- RLS — replace POC \"allow all\" policies with real enforcement
-- ============================================================

-- Drop all existing POC policies
drop policy if exists \"poc_read_categories\"  on categories","drop policy if exists \"poc_read_dishes\"      on dishes","drop policy if exists \"poc_read_orders\"      on orders","drop policy if exists \"poc_insert_orders\"    on orders","drop policy if exists \"poc_update_orders\"    on orders","drop policy if exists \"poc_delete_orders\"    on orders","drop policy if exists \"poc_read_order_items\"   on order_items","drop policy if exists \"poc_insert_order_items\" on order_items","drop policy if exists \"poc_update_order_items\" on order_items","drop policy if exists \"poc_delete_order_items\" on order_items","drop policy if exists \"poc_read_order_events\"  on order_events","drop policy if exists \"poc_insert_order_events\" on order_events","drop policy if exists \"poc_insert_push_subs\" on push_subscriptions","drop policy if exists \"poc_delete_push_subs\" on push_subscriptions","drop policy if exists \"poc_read_push_subs\"   on push_subscriptions","-- Helper function: check if current user is admin
-- Admins have app_metadata.role = ''admin''
create or replace function is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'',
    false
  );
$$","-- Helper function: get current waiter''s id
-- Looks up waiters table by auth.uid()
create or replace function current_waiter_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select id from waiters where auth_id = auth.uid() and is_active = true;
$$","-- Helper function: check if current user is an active waiter
create or replace function is_waiter()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from waiters where auth_id = auth.uid() and is_active = true);
$$","-- Helper function: check if current waiter owns an order
create or replace function is_order_owner(order_row orders)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select order_row.waiter_id = current_waiter_id();
$$","-- ============================================================
-- Categories & Dishes — read-only for authenticated users
-- ============================================================
create policy \"read_categories\" on categories
  for select to authenticated using (true)","create policy \"read_dishes\" on dishes
  for select to authenticated using (true)","-- ============================================================
-- Waiters — read-only for authenticated, write via service_role only
-- (admin manages waiters through the edge function using service role)
-- ============================================================
alter table waiters enable row level security","create policy \"read_waiters\" on waiters
  for select to authenticated using (true)","create policy \"service_role_all_waiters\" on waiters
  for all to service_role using (true) with check (true)","-- Security definer function for public waiter lookup by cédula.
-- The login page needs to verify a cédula exists before showing the PIN
-- keypad, but the user has no session yet. This function exposes only
-- cedula, name, and is_active for active waiters.
create or replace function public.lookup_waiter_by_cedula(p_cedula text)
returns table(cedula text, name text, is_active boolean)
language sql
stable
security definer
set search_path = public
as $$
  select cedula, name, is_active
  from public.waiters
  where cedula = p_cedula and is_active = true;
$$","grant execute on function public.lookup_waiter_by_cedula(text) to anon, authenticated","-- ============================================================
-- Orders — admin: all | waiter: own orders only
-- ============================================================
create policy \"orders_select\" on orders
  for select to authenticated using (
    is_admin() or is_order_owner(orders)
  )","create policy \"orders_insert\" on orders
  for insert to authenticated with check (
    is_admin() or waiter_id = current_waiter_id()
  )","create policy \"orders_update\" on orders
  for update to authenticated using (
    is_admin() or is_order_owner(orders)
  ) with check (
    is_admin() or is_order_owner(orders)
  )","create policy \"orders_delete\" on orders
  for delete to authenticated using (is_admin())","-- ============================================================
-- Order items — admin: all | waiter: own order''s items only
-- ============================================================
create policy \"order_items_select\" on order_items
  for select to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_insert\" on order_items
  for insert to authenticated with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_update\" on order_items
  for update to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  ) with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_items_delete\" on order_items
  for delete to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_items.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","-- ============================================================
-- Order events — admin: read all | waiter: read own, insert own
-- ============================================================
create policy \"order_events_select\" on order_events
  for select to authenticated using (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_events.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","create policy \"order_events_insert\" on order_events
  for insert to authenticated with check (
    is_admin() or exists(
      select 1 from orders o
      where o.id = order_events.order_id
      and o.waiter_id = current_waiter_id()
    )
  )","-- ============================================================
-- Waiters — admin: all | waiter: read own row only
-- ============================================================
create policy \"waiters_select\" on waiters
  for select to authenticated using (
    is_admin() or auth_id = auth.uid()
  )","create policy \"waiters_insert\" on waiters
  for insert to authenticated with check (is_admin())","create policy \"waiters_update\" on waiters
  for update to authenticated using (
    is_admin() or auth_id = auth.uid()
  ) with check (
    is_admin() or auth_id = auth.uid()
  )","create policy \"waiters_delete\" on waiters
  for delete to authenticated using (is_admin())","-- ============================================================
-- Push subscriptions — waiter: manage own only
-- ============================================================
create policy \"push_subs_select\" on push_subscriptions
  for select to authenticated using (
    is_admin() or exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
    )
  )","create policy \"push_subs_insert\" on push_subscriptions
  for insert to authenticated with check (
    exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
      and w.is_active = true
    )
  )","create policy \"push_subs_delete\" on push_subscriptions
  for delete to authenticated using (
    exists(
      select 1 from waiters w
      where w.name = push_subscriptions.waiter_name
      and w.auth_id = auth.uid()
    )
  )","-- ============================================================
-- GRANTs — re-grant with authenticated role (drop anon)
-- ============================================================
revoke select on categories from anon","revoke select on dishes from anon","revoke select on orders from anon","revoke insert on orders from anon","revoke update on orders from anon","revoke select on order_items from anon","revoke insert on order_items from anon","revoke update on order_items from anon","revoke delete on order_items from anon","revoke select on order_events from anon","revoke insert on order_events from anon","revoke insert on push_subscriptions from anon","revoke delete on push_subscriptions from anon","revoke select on push_subscriptions from anon","grant select on categories    to authenticated","grant select on dishes        to authenticated","grant select on orders        to authenticated","grant insert on orders        to authenticated","grant update on orders        to authenticated","grant delete on orders        to authenticated","grant select on order_items   to authenticated","grant insert on order_items   to authenticated","grant update on order_items   to authenticated","grant delete on order_items   to authenticated","grant select on order_events  to authenticated","grant insert on order_events  to authenticated","grant select on waiters       to authenticated","grant insert on waiters       to authenticated","grant update on waiters       to authenticated","grant delete on waiters       to authenticated","grant select on push_subscriptions to authenticated","grant insert on push_subscriptions to authenticated","grant delete on push_subscriptions to authenticated","-- Grant execute on helper functions
grant execute on function is_admin() to authenticated","grant execute on function is_waiter() to authenticated","grant execute on function current_waiter_id() to authenticated","grant execute on function is_order_owner(orders) to authenticated"}', 'auth_and_rls');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260628170000', '{"-- Order adicionals — allows adding items to a served order
-- without creating a new order. Items are flagged with is_additional
-- and grouped by additional_number (round 1, 2, etc.)

-- Add columns to order_items
alter table order_items
  add column if not exists is_additional boolean not null default false,
  add column if not exists additional_number int","-- Index for filtering additional items
create index if not exists idx_order_items_additional
  on order_items (order_id, is_additional, additional_number)"}', 'order_additionals');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629060000', '{"-- Add ''delivery_fee_set'' to the order_events event_type check constraint.
-- This event is logged when an admin sets the delivery fee for an order.

ALTER TABLE order_events DROP CONSTRAINT IF EXISTS order_events_event_type_check","ALTER TABLE order_events ADD CONSTRAINT order_events_event_type_check
  check (event_type in (''created'',''status_changed'',''printed'',''updated'',''cancelled'',''additional_added'',''delivery_fee_set''))"}', 'add_delivery_fee_set_event_type');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629120000', '{"-- Rename order statuses: lista → servida, servida → finalizada
--
-- \"lista\" (kitchen ready) is renamed to \"servida\" (food on table)
-- \"servida\" (was terminal) is renamed to \"finalizada\" (payment confirmed)
--
-- Order matters: rename servida → finalizada FIRST to free up \"servida\",
-- then rename lista → servida.
-- The check constraint must be dropped before the renames (it would block
-- the UPDATE) and re-added with the new allowed values at the end.

-- 1. Drop check constraint (it would block status values not in the old list)
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check","-- 2. Rename servida → finalizada (orders + order_events)
UPDATE orders SET status = ''finalizada'' WHERE status = ''servida''","UPDATE order_events SET from_status = ''finalizada'' WHERE from_status = ''servida''","UPDATE order_events SET to_status = ''finalizada'' WHERE to_status = ''servida''","-- 3. Rename lista → servida (now safe, no conflict)
UPDATE orders SET status = ''servida'' WHERE status = ''lista''","UPDATE order_events SET from_status = ''servida'' WHERE from_status = ''lista''","UPDATE order_events SET to_status = ''servida'' WHERE to_status = ''lista''","-- 4. Re-add check constraint with new allowed values
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  check (status in (''nueva'',''en_cocina'',''servida'',''finalizada'',''adicional''))"}', 'rename_status_lista_to_servida');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629160000', '{"-- Add soft delete columns to waiters and orders tables.
--
-- Waiters: `deleted_at` allows reusing a cédula after soft delete.
--   The unique constraint on `cedula` is replaced with a partial unique
--   index that only applies to non-deleted rows, so a new waiter can be
--   created with the same cédula as a previously deleted one.
--
-- Orders: `deleted_at` allows admin to remove orders from the dashboard
--   without losing the audit trail.

-- 1. Waiters: add deleted_at column
alter table waiters add column if not exists deleted_at timestamptz","-- 2. Waiters: replace unique constraint on cedula with partial unique index
--    Drop the old constraint and create a new one that only applies to
--    non-deleted rows. This allows reusing a cédula after soft delete.
alter table waiters drop constraint if exists waiters_cedula_key","create unique index if not exists waiters_cedula_unique_active
  on waiters (cedula) where deleted_at is null","-- 3. Orders: add deleted_at column
alter table orders add column if not exists deleted_at timestamptz","-- 4. Orders: index for filtering out soft-deleted orders
create index if not exists idx_orders_active
  on orders (created_at) where deleted_at is null"}', 'add_soft_delete');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260629170000', '{"-- Fix RLS policies and helper functions for soft-delete correctness.
--
-- Issues found:
-- 1. orders_select RLS allows waiters to see soft-deleted orders
-- 2. waiters_select RLS allows deleted waiters to read their own profile
-- 3. lookup_waiter_by_cedula doesn''t filter deleted_at (defense in depth)
-- 4. current_waiter_id() doesn''t filter deleted_at (defense in depth)

-- 1. orders_select: waiters should only see non-deleted orders
drop policy if exists orders_select on orders","create policy orders_select on orders
  for select
  using (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )","-- 2. waiters_select: deleted waiters should not be able to read their profile
drop policy if exists waiters_select on waiters","create policy waiters_select on waiters
  for select
  using (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )","-- 2b. orders_update: waiters should not be able to update soft-deleted orders
drop policy if exists orders_update on orders","create policy orders_update on orders
  for update
  using (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )
  with check (
    is_admin()
    OR (is_order_owner(orders.*) AND deleted_at IS NULL)
  )","-- 2c. waiters_update: deleted waiters should not be able to update their profile
--     (e.g. reactivate themselves by setting is_active = true)
drop policy if exists waiters_update on waiters","create policy waiters_update on waiters
  for update
  using (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )
  with check (
    is_admin()
    OR (auth_id = auth.uid() AND deleted_at IS NULL)
  )","-- 3. lookup_waiter_by_cedula: also filter deleted_at (defense in depth)
create or replace function lookup_waiter_by_cedula(p_cedula text)
returns table(cedula text, name text, is_active boolean)
language sql
stable
security definer
set search_path to ''public''
as $$
  select cedula, name, is_active
  from public.waiters
  where cedula = p_cedula
    and is_active = true
    and deleted_at is null;
$$","-- 4. current_waiter_id(): also filter deleted_at (defense in depth)
create or replace function current_waiter_id()
returns uuid
language sql
stable
security definer
set search_path to ''public''
as $$
  select id from waiters
  where auth_id = auth.uid()
    and is_active = true
    and deleted_at is null;
$$"}', 'fix_soft_delete_rls');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260818120000', '{"-- Add ''adicional'' status for orders that have additional items added.
-- This status is set when a waiter/admin adds additional items to a served order.
-- It is NOT shown in the dashboard KPI cards or status filters.
-- Flow: adicional → lista (kitchen finishes the additional) → servida

alter table orders
  drop constraint if exists orders_status_check","alter table orders
  add constraint orders_status_check
  check (status in (''nueva'',''en_cocina'',''lista'',''servida'',''adicional''))"}', 'add_adicional_status');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260818130000', '{"-- Add ''additional_added'' to the order_events event_type check constraint.
-- This event type is used when a waiter or admin adds additional items to an order.
-- The original migration was missing this value, causing the event insert to fail silently.

alter table order_events
  drop constraint if exists order_events_event_type_check","alter table order_events
  add constraint order_events_event_type_check
  check (event_type in (''created'',''status_changed'',''printed'',''updated'',''cancelled'',''additional_added''))"}', 'add_additional_added_event_type');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260630120000', '{"-- ============================================================
-- Add order_number column — a human-readable sequential number
-- for each order, shown on printed commands and searchable in
-- the admin dashboard.
--
-- Uses a Postgres SEQUENCE for gap-free sequential numbering.
-- The sequence is owned by the orders table and incremented via
-- a DEFAULT clause, so every INSERT gets the next number
-- automatically without any app-level logic.
-- ============================================================

-- 1. Add the column (nullable first so existing rows don''t fail)
alter table orders add column if not exists order_number int","-- 2. Create a sequence starting at 1
create sequence if not exists orders_order_number_seq as int","-- 3. Backfill existing rows with sequential numbers (oldest first)
with numbered as (
  select id, row_number() over (order by created_at) as rn
  from orders
  where order_number is null
)
update orders o
set order_number = numbered.rn
from numbered
where o.id = numbered.id","-- 4. Set the sequence to the max existing order_number + 1
select setval(''orders_order_number_seq'',
  coalesce((select max(order_number) from orders), 0) + 1,
  false)","-- 5. Make the column NOT NULL with a DEFAULT from the sequence
alter table orders
  alter column order_number set default nextval(''orders_order_number_seq''),
  alter column order_number set not null","-- 6. Create an index for searching by order_number
create index if not exists idx_orders_order_number on orders(order_number)"}', 'add_order_number');
INSERT INTO supabase_migrations.schema_migrations (version, statements, name) VALUES ('20260630130000', '{"-- ============================================================
-- Add CHECK constraints to prevent invalid numeric data.
--
-- The app validates inputs (e.g. delivery_fee > 0, quantity >= 1),
-- but DB-level constraints are the last line of defense against
-- bugs, direct SQL access, or future code that bypasses validation.
-- ============================================================

-- Dishes: price must be non-negative
alter table dishes
  add constraint dishes_price_non_negative check (price >= 0)","-- Orders: total must be non-negative
alter table orders
  add constraint orders_total_non_negative check (total >= 0)","-- Orders: delivery_fee must be non-negative (0 = no fee / non-delivery)
alter table orders
  add constraint orders_delivery_fee_non_negative check (delivery_fee >= 0)","-- Orders: table_number must be positive (1-17 regular, 18 delivery)
alter table orders
  add constraint orders_table_number_positive check (table_number > 0)","-- Order items: price must be non-negative (snapshot of dish price)
alter table order_items
  add constraint order_items_price_non_negative check (price >= 0)","-- Order items: quantity must be at least 1
alter table order_items
  add constraint order_items_quantity_min_one check (quantity >= 1)"}', 'add_check_constraints');


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--



--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 58, true);


--
-- Name: orders_order_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_order_number_seq', 7, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 2381, true);


--
-- PostgreSQL database dump complete
--

\unrestrict cWyHKX2lCyTAZggfQre0WYWnr6txMx6zY2YNbTodVSXgebRYTlBR25PjQvcEhhX

